import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin, Phone, Calendar, CheckCircle } from "lucide-react";
import type { Guide } from "@shared/schema";

interface GuideCardProps {
  guide: Guide;
  index?: number;
}

export function GuideCard({ guide, index = 0 }: GuideCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      whileHover={{ y: -5 }}
      className="h-full"
    >
      <Card className="overflow-hidden hover-lift h-full flex flex-col">
        <div className="relative">
          <img 
            src={guide.avatar || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e"} 
            alt={guide.name}
            className="w-full h-48 object-cover"
          />
          {guide.verificationStatus === "verified" && (
            <div className="absolute top-4 right-4 bg-green-500 text-white px-2 py-1 rounded-full text-xs font-semibold flex items-center">
              <CheckCircle className="h-3 w-3 mr-1" />
              Verified
            </div>
          )}
        </div>
        
        <CardContent className="p-6 flex-1 flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">{guide.name}</h3>
            <div className="flex items-center">
              <Star className="h-4 w-4 text-yellow-400 fill-current" />
              <span className="text-sm font-semibold ml-1">{guide.rating?.toFixed(1) || "4.8"}</span>
              <span className="text-xs text-gray-500 ml-1">({guide.reviewCount})</span>
            </div>
          </div>
          
          <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
            {guide.specialization} • {guide.experience} years experience
          </p>
          
          {/* Languages */}
          <div className="flex flex-wrap gap-2 mb-4 flex-1">
            {guide.languages?.slice(0, 3).map((language) => (
              <Badge key={language} variant="outline" className="text-xs">
                {language}
              </Badge>
            ))}
          </div>

          {/* Location and Rate */}
          <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
            <div className="flex items-center justify-between mb-3 text-sm text-gray-600 dark:text-gray-400">
              <div className="flex items-center">
                <MapPin className="h-3 w-3 mr-1" />
                <span>{guide.location}</span>
              </div>
              <div className="flex items-center">
                <span>₹{guide.rate}/day</span>
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="flex-1">
                <Phone className="h-3 w-3 mr-1" />
                Contact
              </Button>
              <Button size="sm" className="flex-1 bg-secondary hover:bg-secondary/90">
                <Calendar className="h-3 w-3 mr-1" />
                Book Now
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
