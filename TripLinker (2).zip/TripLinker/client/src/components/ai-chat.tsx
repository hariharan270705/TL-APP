import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Send, Paperclip, Mic, Bot, User, Upload, Route, Calendar, Cloud, Share } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import type { ChatMessage } from "@shared/schema";

interface AiChatProps {
  userId?: string;
}

export function AiChat({ userId = "demo-user" }: AiChatProps) {
  const [message, setMessage] = useState("");
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  // Fetch chat messages
  const { data: messages = [], isLoading } = useQuery({
    queryKey: ["/api/chat", userId],
    queryFn: () => api.chat.getMessages(userId).then(res => res.json()),
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      return api.chat.sendAiMessage({ message: content, userId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat", userId] });
      setMessage("");
    },
  });

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || sendMessageMutation.isPending) return;
    
    sendMessageMutation.mutate(message);
  };

  const handleVoiceInput = () => {
    if ('webkitSpeechRecognition' in window) {
      const recognition = new (window as any).webkitSpeechRecognition();
      recognition.lang = 'en-US';
      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setMessage(transcript);
      };
      recognition.start();
    }
  };

  const handleFileUpload = () => {
    // Placeholder for file upload functionality
    console.log("File upload clicked");
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const quickActions = [
    { icon: Route, label: "Generate Route", action: () => setMessage("Generate a route for my trip") },
    { icon: Calendar, label: "Plan Schedule", action: () => setMessage("Help me plan my travel schedule") },
    { icon: Cloud, label: "Weather Check", action: () => setMessage("Check weather for my destination") },
    { icon: Share, label: "Share Plan", action: () => setMessage("Share my travel plan") },
  ];

  return (
    <div className="grid lg:grid-cols-2 gap-12 items-start">
      {/* AI Chat Interface */}
      <Card className="bg-white/10 backdrop-blur-lg border-white/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center">
                <Bot className="h-6 w-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-white">TripLinker AI</CardTitle>
                <p className="text-white/70 text-sm">Your intelligent travel companion</p>
              </div>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-green-400 rounded-full mr-2 animate-pulse" />
              <span className="text-white/70 text-sm">Online</span>
            </div>
          </div>
        </CardHeader>

        <CardContent>
          {/* Chat Messages */}
          <div className="h-80 overflow-y-auto mb-6 space-y-4 scrollbar-thin scrollbar-thumb-white/20">
            {isLoading ? (
              <div className="flex items-center justify-center h-full">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white/50" />
              </div>
            ) : (
              <AnimatePresence>
                {messages.map((msg: ChatMessage, index: number) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ delay: index * 0.1 }}
                    className={`flex items-start space-x-3 ${
                      msg.role === "user" ? "justify-end" : ""
                    }`}
                  >
                    {msg.role === "assistant" && (
                      <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center flex-shrink-0">
                        <Bot className="h-4 w-4 text-white" />
                      </div>
                    )}
                    <div
                      className={`rounded-2xl p-4 max-w-xs ${
                        msg.role === "user"
                          ? "bg-primary text-white rounded-tr-sm"
                          : "bg-white/20 text-white rounded-tl-sm"
                      }`}
                    >
                      <p className="text-sm">{msg.content}</p>
                    </div>
                    {msg.role === "user" && (
                      <div className="w-8 h-8 bg-gray-400 rounded-full flex items-center justify-center flex-shrink-0">
                        <User className="h-4 w-4 text-white" />
                      </div>
                    )}
                  </motion.div>
                ))}
              </AnimatePresence>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Chat Input */}
          <form onSubmit={handleSendMessage} className="flex space-x-3">
            <div className="flex-1 relative">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Ask me anything about your trip..."
                className="bg-white/10 border-white/20 text-white placeholder-white/50 focus:ring-2 focus:ring-secondary focus:border-transparent backdrop-blur-sm pr-12"
                disabled={sendMessageMutation.isPending}
              />
              <Button
                type="button"
                size="icon"
                variant="ghost"
                onClick={handleFileUpload}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 text-white/50 hover:text-white"
              >
                <Paperclip className="h-4 w-4" />
              </Button>
            </div>
            <Button
              type="submit"
              size="icon"
              disabled={sendMessageMutation.isPending || !message.trim()}
              className="bg-secondary hover:bg-secondary/90"
            >
              {sendMessageMutation.isPending ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
            <Button
              type="button"
              size="icon"
              onClick={handleVoiceInput}
              className={`bg-accent hover:bg-accent/90 ${isListening ? 'animate-pulse' : ''}`}
            >
              <Mic className="h-4 w-4" />
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Features Panel */}
      <div className="space-y-6">
        {/* File Upload */}
        <Card className="bg-white/10 backdrop-blur-lg border-white/20">
          <CardContent className="p-6">
            <h4 className="text-xl font-bold text-white mb-4">Upload Travel Photos</h4>
            <div 
              className="border-2 border-dashed border-white/30 rounded-xl p-8 text-center hover:border-white/50 transition-colors cursor-pointer"
              onClick={handleFileUpload}
            >
              <Upload className="h-12 w-12 text-white/70 mb-4 mx-auto" />
              <p className="text-white/90 mb-2">Drag & drop your photos here</p>
              <p className="text-white/60 text-sm">JPG, PNG, MP4 up to 10MB</p>
              <Button className="mt-4 bg-secondary hover:bg-secondary/90" onClick={handleFileUpload}>
                Browse Files
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4">
          {quickActions.map((action, index) => (
            <motion.div key={action.label} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button
                variant="ghost"
                onClick={action.action}
                className="h-auto bg-white/10 backdrop-blur-lg border border-white/20 hover:bg-white/20 text-white flex flex-col items-center p-4 w-full"
              >
                <action.icon className="h-6 w-6 mb-2" />
                <span className="text-sm">{action.label}</span>
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
