import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Languages, 
  Play,
  Pause,
  RotateCcw,
  Loader2,
  CheckCircle,
  AlertTriangle,
  MessageCircle
} from "lucide-react";

interface VoiceAssistantProps {
  onTranslation?: (originalText: string, translatedText: string, targetLanguage: string) => void;
  onVoiceCommand?: (command: string) => void;
}

interface SpeechResult {
  text: string;
  confidence: number;
  language: string;
  timestamp: number;
}

interface TranslationResult {
  originalText: string;
  translatedText: string;
  sourceLanguage: string;
  targetLanguage: string;
  timestamp: number;
}

const SUPPORTED_LANGUAGES = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'hi', name: 'Hindi', flag: '🇮🇳' },
  { code: 'ta', name: 'Tamil', flag: '🇮🇳' },
  { code: 'te', name: 'Telugu', flag: '🇮🇳' },
  { code: 'kn', name: 'Kannada', flag: '🇮🇳' },
  { code: 'ml', name: 'Malayalam', flag: '🇮🇳' },
  { code: 'bn', name: 'Bengali', flag: '🇮🇳' },
  { code: 'gu', name: 'Gujarati', flag: '🇮🇳' },
  { code: 'mr', name: 'Marathi', flag: '🇮🇳' },
  { code: 'pa', name: 'Punjabi', flag: '🇮🇳' },
  { code: 'ur', name: 'Urdu', flag: '🇵🇰' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'de', name: 'German', flag: '🇩🇪' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', flag: '🇰🇷' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  { code: 'ar', name: 'Arabic', flag: '🇸🇦' },
  { code: 'th', name: 'Thai', flag: '🇹🇭' },
  { code: 'vi', name: 'Vietnamese', flag: '🇻🇳' }
];

export function VoiceAssistant({ onTranslation, onVoiceCommand }: VoiceAssistantProps) {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [targetLanguage, setTargetLanguage] = useState('hi');
  const [speechResults, setSpeechResults] = useState<SpeechResult[]>([]);
  const [translations, setTranslations] = useState<TranslationResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isSupported, setIsSupported] = useState(false);

  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  
  // Extend Window interface for Speech Recognition
  declare global {
    interface Window {
      webkitSpeechRecognition: any;
      SpeechRecognition: any;
    }
  }
  const { toast } = useToast();

  // Check browser support on mount
  useEffect(() => {
    const checkSupport = () => {
      const speechRecognition = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
      const speechSynthesis = 'speechSynthesis' in window;
      setIsSupported(speechRecognition && speechSynthesis);
      
      if (!speechRecognition || !speechSynthesis) {
        setError("Speech features not supported in this browser. Please use Chrome, Edge, or Safari.");
      }
    };

    checkSupport();
  }, []);

  // Initialize speech recognition
  useEffect(() => {
    if (!isSupported) return;

    const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = currentLanguage;

      recognitionRef.current.onresult = (event) => {
        const results = Array.from(event.results);
        const finalResults = results
          .filter(result => result.isFinal)
          .map(result => result[0]);

        if (finalResults.length > 0) {
          const latestResult = finalResults[finalResults.length - 1];
          const speechResult: SpeechResult = {
            text: latestResult.transcript,
            confidence: latestResult.confidence,
            language: currentLanguage,
            timestamp: Date.now()
          };

          setSpeechResults(prev => [speechResult, ...prev.slice(0, 9)]);
          handleSpeechResult(speechResult);
        }
      };

      recognitionRef.current.onerror = (event) => {
        setError(`Speech recognition error: ${event.error}`);
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }

    synthRef.current = window.speechSynthesis;

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [currentLanguage, isSupported]);

  // Handle speech recognition results
  const handleSpeechResult = async (result: SpeechResult) => {
    try {
      // Check for voice commands
      const command = result.text.toLowerCase();
      if (command.includes('translate') || command.includes('convert')) {
        await translateText(result.text, currentLanguage, targetLanguage);
        onVoiceCommand?.(result.text);
      } else if (command.includes('speak') || command.includes('say')) {
        await speakText(result.text, targetLanguage);
      } else {
        // Auto-translate if different from target language
        if (currentLanguage !== targetLanguage) {
          await translateText(result.text, currentLanguage, targetLanguage);
        }
      }
    } catch (error) {
      console.error('Error handling speech result:', error);
    }
  };

  // Start/stop voice recognition
  const toggleListening = () => {
    if (!isSupported || !recognitionRef.current) {
      toast({
        title: "Voice Recognition Unavailable",
        description: "Please use a supported browser (Chrome, Edge, Safari)",
        variant: "destructive"
      });
      return;
    }

    setError(null);

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      recognitionRef.current.lang = currentLanguage;
      recognitionRef.current.start();
      setIsListening(true);
      toast({
        title: "Voice Recognition Started",
        description: `Listening in ${SUPPORTED_LANGUAGES.find(l => l.code === currentLanguage)?.name}...`,
      });
    }
  };

  // Translate text using LibreTranslate (mock implementation)
  const translateText = async (text: string, fromLang: string, toLang: string) => {
    if (fromLang === toLang) return;
    
    setIsProcessing(true);
    try {
      // Mock translation - in real app, use LibreTranslate API
      const translations: Record<string, Record<string, string>> = {
        'en': {
          'hi': 'नमस्ते, मैं आपकी यात्रा में मदद करूंगा',
          'ta': 'வணக்கம், நான் உங்கள் பயணத்தில் உதவுவேன்',
          'te': 'నమస్కారం, నేను మీ ప్రయాణంలో సహాయం చేస్తాను'
        },
        'hi': {
          'en': 'Hello, I will help you with your travel',
          'ta': 'வணக்கம், நான் உங்கள் பயணத்தில் உதவுவேன்'
        }
      };

      const translatedText = translations[fromLang]?.[toLang] || `[Translated from ${fromLang} to ${toLang}]: ${text}`;
      
      const translation: TranslationResult = {
        originalText: text,
        translatedText,
        sourceLanguage: fromLang,
        targetLanguage: toLang,
        timestamp: Date.now()
      };

      setTranslations(prev => [translation, ...prev.slice(0, 4)]);
      onTranslation?.(text, translatedText, toLang);

      // Auto-speak the translation
      await speakText(translatedText, toLang);

      toast({
        title: "Translation Complete",
        description: `Translated from ${SUPPORTED_LANGUAGES.find(l => l.code === fromLang)?.name} to ${SUPPORTED_LANGUAGES.find(l => l.code === toLang)?.name}`,
      });

    } catch (error) {
      setError("Translation failed. Please try again.");
      toast({
        title: "Translation Failed",
        description: "Unable to translate text. Please check your connection.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Text-to-speech
  const speakText = async (text: string, language: string) => {
    if (!synthRef.current) return;
    
    setIsSpeaking(true);
    try {
      // Cancel any ongoing speech
      synthRef.current.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = language;
      utterance.rate = 0.9;
      utterance.pitch = 1;
      
      // Try to find a voice for the language
      const voices = synthRef.current.getVoices();
      const voice = voices.find(v => v.lang.startsWith(language)) || 
                   voices.find(v => v.lang.startsWith(language.split('-')[0]));
      
      if (voice) {
        utterance.voice = voice;
      }

      utterance.onend = () => {
        setIsSpeaking(false);
      };

      utterance.onerror = () => {
        setIsSpeaking(false);
        setError("Text-to-speech failed");
      };

      synthRef.current.speak(utterance);
    } catch (error) {
      setIsSpeaking(false);
      setError("Text-to-speech unavailable");
    }
  };

  // Stop speech synthesis
  const stopSpeaking = () => {
    if (synthRef.current) {
      synthRef.current.cancel();
      setIsSpeaking(false);
    }
  };

  return (
    <motion.div
      className="space-y-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Voice Assistant Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="h-5 w-5" />
            Voice Assistant & Translator
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Language Selection */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">From Language</label>
              <Select value={currentLanguage} onValueChange={setCurrentLanguage}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SUPPORTED_LANGUAGES.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">To Language</label>
              <Select value={targetLanguage} onValueChange={setTargetLanguage}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SUPPORTED_LANGUAGES.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Voice Controls */}
          <div className="flex items-center gap-4">
            <Button
              onClick={toggleListening}
              disabled={!isSupported || isProcessing}
              className={isListening ? "bg-red-500 hover:bg-red-600" : ""}
            >
              {isListening ? (
                <>
                  <MicOff className="h-4 w-4 mr-2" />
                  Stop Listening
                </>
              ) : (
                <>
                  <Mic className="h-4 w-4 mr-2" />
                  Start Voice Input
                </>
              )}
            </Button>

            <Button
              onClick={stopSpeaking}
              disabled={!isSpeaking}
              variant="outline"
            >
              {isSpeaking ? (
                <>
                  <VolumeX className="h-4 w-4 mr-2" />
                  Stop Speaking
                </>
              ) : (
                <>
                  <Volume2 className="h-4 w-4 mr-2" />
                  Text-to-Speech
                </>
              )}
            </Button>

            {isProcessing && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span className="text-sm">Processing...</span>
              </div>
            )}
          </div>

          {/* Status Indicators */}
          <div className="flex items-center gap-2 flex-wrap">
            {isListening && (
              <Badge variant="default" className="animate-pulse">
                <Mic className="h-3 w-3 mr-1" />
                Listening
              </Badge>
            )}
            {isSpeaking && (
              <Badge variant="secondary" className="animate-pulse">
                <Volume2 className="h-3 w-3 mr-1" />
                Speaking
              </Badge>
            )}
            {isProcessing && (
              <Badge variant="outline">
                <Languages className="h-3 w-3 mr-1" />
                Translating
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recent Translations */}
      <AnimatePresence>
        {translations.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Languages className="h-5 w-5" />
                  Recent Translations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {translations.map((translation, idx) => (
                    <motion.div
                      key={translation.timestamp}
                      className="p-4 rounded-lg bg-muted/50 space-y-2"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.1 }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            {SUPPORTED_LANGUAGES.find(l => l.code === translation.sourceLanguage)?.flag} →{' '}
                            {SUPPORTED_LANGUAGES.find(l => l.code === translation.targetLanguage)?.flag}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {new Date(translation.timestamp).toLocaleTimeString()}
                          </span>
                        </div>
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => speakText(translation.translatedText, translation.targetLanguage)}
                        >
                          <Play className="h-3 w-3" />
                        </Button>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="text-sm text-muted-foreground">
                          <strong>Original:</strong> {translation.originalText}
                        </div>
                        <div className="text-sm font-medium">
                          <strong>Translation:</strong> {translation.translatedText}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Voice Commands Help */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mic className="h-5 w-5" />
            Voice Commands
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div className="space-y-2">
              <h4 className="font-medium">Travel Commands:</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• "Plan a trip to Goa"</li>
                <li>• "Find guides in Rajasthan"</li>
                <li>• "What's the weather like?"</li>
                <li>• "Recommend restaurants nearby"</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium">Translation Commands:</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• "Translate to Hindi"</li>
                <li>• "How do you say hello?"</li>
                <li>• "Speak this in Tamil"</li>
                <li>• "Convert to local language"</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// Extend Window interface for Speech Recognition
declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }
}