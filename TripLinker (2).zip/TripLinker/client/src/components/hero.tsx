import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Plane, Mountain, Camera, Bot, MapPin } from "lucide-react";
import { MOCK_STATS } from "@/lib/constants";
import { Link } from "wouter";

export function Hero() {
  const stats = [
    { label: "Destinations", value: MOCK_STATS.destinations },
    { label: "Verified Guides", value: MOCK_STATS.guides },
    { label: "Languages", value: MOCK_STATS.languages },
    { label: "Happy Travelers", value: MOCK_STATS.users },
  ];

  const floatingElements = [
    { icon: Plane, className: "top-20 left-10 text-6xl animate-float" },
    { icon: Mountain, className: "top-40 right-20 text-4xl animate-bounce-slow" },
    { icon: Camera, className: "bottom-32 left-20 text-5xl animate-float animation-delay-400" },
  ];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Floating background elements */}
      <div className="floating-elements">
        {floatingElements.map((Element, index) => (
          <motion.div
            key={index}
            className={`absolute ${Element.className} text-white/20`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.1 }}
            transition={{ delay: index * 0.2 }}
          >
            <Element.icon />
          </motion.div>
        ))}
      </div>

      {/* Hero background */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `linear-gradient(rgba(37, 99, 235, 0.3), rgba(16, 185, 129, 0.3)), url('https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')`
        }}
      />

      <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
        <motion.h1 
          className="text-5xl md:text-7xl font-bold mb-6"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          Discover Your Next
          <motion.span 
            className="block text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          >
            Adventure
          </motion.span>
        </motion.h1>

        <motion.p 
          className="text-xl md:text-2xl mb-8 opacity-90"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
        >
          AI-powered travel planning with local guides, real-time assistance, and personalized experiences
        </motion.p>

        <motion.div 
          className="flex flex-col md:flex-row gap-4 justify-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.8 }}
        >
          <Link href="/ai-planner">
            <Button size="lg" className="bg-secondary hover:bg-secondary/90 text-white px-8 py-4 text-lg font-semibold hover-lift">
              <Bot className="mr-2 h-5 w-5" />
              Start AI Planning
            </Button>
          </Link>
          <Link href="/destinations">
            <Button 
              size="lg" 
              variant="outline" 
              className="bg-white/20 hover:bg-white/30 text-white border-white/30 px-8 py-4 text-lg font-semibold hover-lift backdrop-blur-sm"
            >
              <MapPin className="mr-2 h-5 w-5" />
              Explore Destinations
            </Button>
          </Link>
        </motion.div>

        {/* Quick Stats */}
        <motion.div 
          className="grid grid-cols-2 md:grid-cols-4 gap-6"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.8 }}
        >
          {stats.map((stat, index) => (
            <motion.div 
              key={stat.label}
              className="text-center"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1 + index * 0.1, duration: 0.5 }}
              whileHover={{ scale: 1.05 }}
            >
              <div className="text-3xl font-bold">{stat.value}</div>
              <div className="text-sm opacity-80">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
