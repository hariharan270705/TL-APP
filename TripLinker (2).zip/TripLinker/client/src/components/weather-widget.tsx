import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Cloud, 
  Sun, 
  CloudRain, 
  Snowflake, 
  Wind, 
  Thermometer,
  Droplets,
  Eye,
  Sunrise,
  Sunset,
  MapPin
} from "lucide-react";

interface WeatherData {
  location: string;
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  visibility: number;
  sunrise: string;
  sunset: string;
  forecast: Array<{
    day: string;
    high: number;
    low: number;
    condition: string;
    icon: string;
  }>;
}

interface WeatherWidgetProps {
  location?: string;
}

export function WeatherWidget({ location = "Current Location" }: WeatherWidgetProps) {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // Fetch weather data
  const fetchWeather = async (locationQuery: string) => {
    setIsLoading(true);
    try {
      // Mock weather data - in real app, use OpenWeatherMap or WeatherAPI
      const mockWeatherData: WeatherData = {
        location: locationQuery,
        temperature: Math.round(Math.random() * 20) + 20, // 20-40°C
        condition: ["Sunny", "Partly Cloudy", "Cloudy", "Light Rain"][Math.floor(Math.random() * 4)],
        humidity: Math.round(Math.random() * 40) + 40, // 40-80%
        windSpeed: Math.round(Math.random() * 20) + 5, // 5-25 km/h
        visibility: Math.round(Math.random() * 5) + 5, // 5-10 km
        sunrise: "06:30 AM",
        sunset: "06:45 PM",
        forecast: [
          { day: "Today", high: 32, low: 24, condition: "Sunny", icon: "☀️" },
          { day: "Tomorrow", high: 29, low: 22, condition: "Partly Cloudy", icon: "⛅" },
          { day: "Thu", high: 27, low: 20, condition: "Cloudy", icon: "☁️" },
          { day: "Fri", high: 31, low: 23, condition: "Sunny", icon: "☀️" },
          { day: "Sat", high: 26, low: 19, condition: "Light Rain", icon: "🌦️" },
          { day: "Sun", high: 28, low: 21, condition: "Partly Cloudy", icon: "⛅" },
          { day: "Mon", high: 30, low: 22, condition: "Sunny", icon: "☀️" }
        ]
      };

      setWeather(mockWeatherData);
      toast({
        title: "Weather Updated",
        description: `Weather information loaded for ${locationQuery}`,
      });
    } catch (error) {
      toast({
        title: "Weather Unavailable",
        description: "Unable to fetch weather data. Please try again later.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Get weather icon component
  const getWeatherIcon = (condition: string) => {
    const iconClass = "h-8 w-8";
    switch (condition.toLowerCase()) {
      case "sunny":
        return <Sun className={`${iconClass} text-yellow-500`} />;
      case "partly cloudy":
        return <Cloud className={`${iconClass} text-gray-400`} />;
      case "cloudy":
        return <Cloud className={`${iconClass} text-gray-600`} />;
      case "light rain":
      case "rain":
        return <CloudRain className={`${iconClass} text-blue-500`} />;
      case "snow":
        return <Snowflake className={`${iconClass} text-blue-200`} />;
      default:
        return <Sun className={`${iconClass} text-yellow-500`} />;
    }
  };

  // Load weather on mount
  useEffect(() => {
    fetchWeather(location);
  }, [location]);

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-6 bg-muted rounded w-1/2"></div>
            <div className="h-12 bg-muted rounded"></div>
            <div className="grid grid-cols-3 gap-4">
              <div className="h-8 bg-muted rounded"></div>
              <div className="h-8 bg-muted rounded"></div>
              <div className="h-8 bg-muted rounded"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!weather) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Cloud className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground">Weather data unavailable</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {/* Current Weather */}
      <Card className="overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            {weather.location}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Main Weather Display */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {getWeatherIcon(weather.condition)}
              <div>
                <div className="text-3xl font-bold text-foreground">
                  {weather.temperature}°C
                </div>
                <div className="text-muted-foreground">{weather.condition}</div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Feels like</div>
              <div className="text-lg font-semibold">{weather.temperature + 2}°C</div>
            </div>
          </div>

          {/* Weather Details */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50">
              <Droplets className="h-4 w-4 text-blue-500" />
              <div>
                <div className="text-xs text-muted-foreground">Humidity</div>
                <div className="font-semibold">{weather.humidity}%</div>
              </div>
            </div>
            
            <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50">
              <Wind className="h-4 w-4 text-gray-500" />
              <div>
                <div className="text-xs text-muted-foreground">Wind</div>
                <div className="font-semibold">{weather.windSpeed} km/h</div>
              </div>
            </div>
            
            <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50">
              <Eye className="h-4 w-4 text-indigo-500" />
              <div>
                <div className="text-xs text-muted-foreground">Visibility</div>
                <div className="font-semibold">{weather.visibility} km</div>
              </div>
            </div>
            
            <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50">
              <Sunrise className="h-4 w-4 text-orange-500" />
              <div>
                <div className="text-xs text-muted-foreground">Sunrise</div>
                <div className="font-semibold">{weather.sunrise}</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 7-Day Forecast */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Thermometer className="h-5 w-5" />
            7-Day Forecast
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {weather.forecast.map((day, idx) => (
              <motion.div
                key={day.day}
                className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 text-left">
                    <div className="font-medium text-foreground">{day.day}</div>
                  </div>
                  <div className="text-2xl">{day.icon}</div>
                  <div className="text-sm text-muted-foreground">{day.condition}</div>
                </div>
                
                <div className="flex items-center gap-2">
                  <div className="text-right">
                    <div className="font-semibold text-foreground">{day.high}°</div>
                    <div className="text-sm text-muted-foreground">{day.low}°</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Travel Advisory */}
      <Card>
        <CardHeader>
          <CardTitle>Travel Advisory</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {weather.condition === "Sunny" && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-green-50 dark:bg-green-900/20">
                <Sun className="h-4 w-4 text-green-600" />
                <div>
                  <div className="font-medium text-green-900 dark:text-green-100">Perfect for Sightseeing</div>
                  <div className="text-sm text-green-700 dark:text-green-200">Great weather for outdoor activities and photography</div>
                </div>
              </div>
            )}
            
            {weather.condition.includes("Rain") && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                <CloudRain className="h-4 w-4 text-blue-600" />
                <div>
                  <div className="font-medium text-blue-900 dark:text-blue-100">Carry an Umbrella</div>
                  <div className="text-sm text-blue-700 dark:text-blue-200">Light rain expected. Indoor attractions recommended</div>
                </div>
              </div>
            )}
            
            {weather.temperature > 35 && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-orange-50 dark:bg-orange-900/20">
                <Thermometer className="h-4 w-4 text-orange-600" />
                <div>
                  <div className="font-medium text-orange-900 dark:text-orange-100">Hot Weather Alert</div>
                  <div className="text-sm text-orange-700 dark:text-orange-200">Stay hydrated and plan indoor activities during peak hours</div>
                </div>
              </div>
            )}
            
            <div className="flex items-center gap-2 p-3 rounded-lg bg-purple-50 dark:bg-purple-900/20">
              <Sunset className="h-4 w-4 text-purple-600" />
              <div>
                <div className="font-medium text-purple-900 dark:text-purple-100">Golden Hour</div>
                <div className="text-sm text-purple-700 dark:text-purple-200">Best photography time: {weather.sunset}</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}