import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin, Users, Cloud } from "lucide-react";
import type { Destination } from "@shared/schema";

interface DestinationCardProps {
  destination: Destination;
  index?: number;
}

export function DestinationCard({ destination, index = 0 }: DestinationCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      whileHover={{ y: -5 }}
      className="h-full"
    >
      <Card className="overflow-hidden hover-lift h-full flex flex-col">
        <div className="relative">
          <img 
            src={destination.images?.[0] || "https://images.unsplash.com/photo-1506905925346-21bda4d32df4"} 
            alt={destination.name}
            className="w-full h-48 object-cover"
          />
          <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-2 py-1 flex items-center space-x-1">
            <Star className="h-3 w-3 text-yellow-500 fill-current" />
            <span className="text-xs font-semibold">{destination.rating?.toFixed(1) || "4.5"}</span>
          </div>
        </div>
        
        <CardContent className="p-6 flex-1 flex flex-col">
          <div className="flex justify-between items-start mb-3">
            <div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">{destination.name}</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm flex items-center">
                <MapPin className="h-3 w-3 mr-1" />
                {destination.state}, {destination.country}
              </p>
            </div>
          </div>
          
          {/* Weather and Guides Info */}
          <div className="flex items-center space-x-4 mb-4 text-sm text-gray-600 dark:text-gray-400">
            <div className="flex items-center">
              <Cloud className="h-3 w-3 mr-1" />
              <span>Weather: Available</span>
            </div>
            <div className="flex items-center">
              <Users className="h-3 w-3 mr-1" />
              <span>{destination.guidesAvailable} guides</span>
            </div>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-4 flex-1">
            {destination.tags?.slice(0, 3).map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>

          <Button className="w-full bg-primary hover:bg-primary/90 text-white font-semibold">
            <MapPin className="mr-2 h-4 w-4" />
            Explore Destination
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}
