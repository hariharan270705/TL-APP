import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  MapPin, 
  Navigation, 
  Loader2, 
  Satellite, 
  Map, 
  Compass,
  Target,
  Share2,
  Camera,
  Coffee,
  ShoppingBag,
  Utensils,
  Hotel
} from "lucide-react";

interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  address?: string;
  timestamp: number;
}

interface NearbyPlace {
  id: string;
  name: string;
  category: string;
  distance: number;
  rating: number;
  address: string;
  isOpen: boolean;
}

interface LocationTrackerProps {
  onLocationUpdate?: (location: LocationData) => void;
  showNearbyPlaces?: boolean;
}

export function LocationTracker({ onLocationUpdate, showNearbyPlaces = true }: LocationTrackerProps) {
  const [currentLocation, setCurrentLocation] = useState<LocationData | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [nearbyPlaces, setNearbyPlaces] = useState<NearbyPlace[]>([]);
  const [mapView, setMapView] = useState<'map' | 'satellite'>('map');
  const [error, setError] = useState<string | null>(null);
  
  const watchIdRef = useRef<number | null>(null);
  const { toast } = useToast();

  // Check if geolocation is supported
  const isGeolocationSupported = 'geolocation' in navigator;

  // Get current location
  const getCurrentLocation = async () => {
    if (!isGeolocationSupported) {
      setError("Geolocation is not supported by this browser");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000 // 5 minutes
        });
      });

      const locationData: LocationData = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy,
        timestamp: Date.now()
      };

      // Get address from coordinates (reverse geocoding)
      try {
        const address = await reverseGeocode(locationData.latitude, locationData.longitude);
        locationData.address = address;
      } catch (error) {
        console.log("Reverse geocoding failed:", error);
      }

      setCurrentLocation(locationData);
      onLocationUpdate?.(locationData);

      if (showNearbyPlaces) {
        await findNearbyPlaces(locationData.latitude, locationData.longitude);
      }

      toast({
        title: "Location Updated",
        description: `Found your location with ${Math.round(locationData.accuracy)}m accuracy`,
      });

    } catch (error: any) {
      const errorMessage = getGeolocationErrorMessage(error);
      setError(errorMessage);
      toast({
        title: "Location Error",
        description: errorMessage,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Start continuous tracking
  const startTracking = () => {
    if (!isGeolocationSupported) return;

    setIsTracking(true);
    setError(null);

    watchIdRef.current = navigator.geolocation.watchPosition(
      (position) => {
        const locationData: LocationData = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: Date.now()
        };

        setCurrentLocation(locationData);
        onLocationUpdate?.(locationData);
      },
      (error) => {
        const errorMessage = getGeolocationErrorMessage(error);
        setError(errorMessage);
        setIsTracking(false);
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 60000 // 1 minute
      }
    );

    toast({
      title: "Location Tracking Started",
      description: "Your location will be updated automatically",
    });
  };

  // Stop tracking
  const stopTracking = () => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    setIsTracking(false);
    
    toast({
      title: "Location Tracking Stopped",
      description: "Location updates have been paused",
    });
  };

  // Reverse geocoding using Nominatim (OpenStreetMap)
  const reverseGeocode = async (lat: number, lon: number): Promise<string> => {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=16&addressdetails=1`
    );
    
    if (!response.ok) throw new Error('Reverse geocoding failed');
    
    const data = await response.json();
    return data.display_name || 'Address not found';
  };

  // Find nearby places (mock data - in production, use Google Places API or similar)
  const findNearbyPlaces = async (lat: number, lon: number) => {
    // Mock nearby places data
    const mockPlaces: NearbyPlace[] = [
      {
        id: "1",
        name: "Tourist Information Center",
        category: "Information",
        distance: 0.2,
        rating: 4.5,
        address: "123 Main Street",
        isOpen: true
      },
      {
        id: "2", 
        name: "Historic Museum",
        category: "Museum",
        distance: 0.5,
        rating: 4.7,
        address: "456 Heritage Ave",
        isOpen: true
      },
      {
        id: "3",
        name: "Local Café",
        category: "Restaurant",
        distance: 0.3,
        rating: 4.2,
        address: "789 Coffee Lane",
        isOpen: true
      },
      {
        id: "4",
        name: "Souvenir Shop",
        category: "Shopping",
        distance: 0.4,
        rating: 4.0,
        address: "321 Shopping Street",
        isOpen: false
      },
      {
        id: "5",
        name: "Grand Hotel",
        category: "Hotel", 
        distance: 0.8,
        rating: 4.6,
        address: "567 Luxury Boulevard",
        isOpen: true
      }
    ];

    setNearbyPlaces(mockPlaces);
  };

  // Get error message for geolocation errors
  const getGeolocationErrorMessage = (error: GeolocationPositionError): string => {
    switch (error.code) {
      case error.PERMISSION_DENIED:
        return "Location access denied. Please enable location permissions.";
      case error.POSITION_UNAVAILABLE:
        return "Location information unavailable. Please try again.";
      case error.TIMEOUT:
        return "Location request timed out. Please try again.";
      default:
        return "An unknown location error occurred.";
    }
  };

  // Share location
  const shareLocation = async () => {
    if (!currentLocation) return;

    const locationUrl = `https://www.google.com/maps?q=${currentLocation.latitude},${currentLocation.longitude}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'My Current Location',
          text: 'Check out where I am!',
          url: locationUrl
        });
      } catch (error) {
        console.log('Share cancelled');
      }
    } else {
      await navigator.clipboard.writeText(locationUrl);
      toast({
        title: "Location Copied",
        description: "Location link copied to clipboard",
      });
    }
  };

  // Open in maps app
  const openInMaps = () => {
    if (!currentLocation) return;
    
    const url = `https://www.google.com/maps?q=${currentLocation.latitude},${currentLocation.longitude}`;
    window.open(url, '_blank');
  };

  // Get category icon
  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'restaurant':
      case 'food':
        return <Utensils className="h-4 w-4" />;
      case 'shopping':
        return <ShoppingBag className="h-4 w-4" />;
      case 'hotel':
      case 'accommodation':
        return <Hotel className="h-4 w-4" />;
      case 'museum':
      case 'attraction':
        return <Camera className="h-4 w-4" />;
      default:
        return <MapPin className="h-4 w-4" />;
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  if (!isGeolocationSupported) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <MapPin className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">Location Not Supported</h3>
          <p className="text-muted-foreground">
            Your browser doesn't support location services.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Location Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Navigation className="h-5 w-5" />
            Location Tracker
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Current Location Display */}
          {currentLocation ? (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-3"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Target className="h-4 w-4 text-green-500" />
                    <span className="font-medium">Current Location</span>
                    <Badge variant="secondary" className="text-xs">
                      ±{Math.round(currentLocation.accuracy)}m
                    </Badge>
                  </div>
                  
                  <div className="text-sm text-muted-foreground space-y-1">
                    <div>Lat: {currentLocation.latitude.toFixed(6)}</div>
                    <div>Lng: {currentLocation.longitude.toFixed(6)}</div>
                    {currentLocation.address && (
                      <div className="text-xs mt-2 p-2 bg-muted rounded">
                        {currentLocation.address}
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={shareLocation}
                  >
                    <Share2 className="h-4 w-4" />
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={openInMaps}
                  >
                    <Map className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </motion.div>
          ) : error ? (
            <div className="text-center py-4">
              <MapPin className="h-8 w-8 mx-auto text-red-500 mb-2" />
              <p className="text-sm text-red-600 mb-3">{error}</p>
            </div>
          ) : (
            <div className="text-center py-4">
              <Compass className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                Location not detected yet
              </p>
            </div>
          )}

          {/* Control Buttons */}
          <div className="flex gap-2">
            <Button
              onClick={getCurrentLocation}
              disabled={isLoading}
              className="flex-1"
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Target className="h-4 w-4 mr-2" />
              )}
              Get Location
            </Button>
            
            {isTracking ? (
              <Button
                variant="destructive"
                onClick={stopTracking}
                className="flex-1"
              >
                Stop Tracking
              </Button>
            ) : (
              <Button
                variant="outline"
                onClick={startTracking}
                disabled={!currentLocation}
                className="flex-1"
              >
                Start Tracking
              </Button>
            )}
          </div>

          {isTracking && (
            <div className="flex items-center gap-2 text-sm text-green-600">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              Live tracking active
            </div>
          )}
        </CardContent>
      </Card>

      {/* Nearby Places */}
      {showNearbyPlaces && currentLocation && nearbyPlaces.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Nearby Places
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {nearbyPlaces.map((place) => (
                <motion.div
                  key={place.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-full bg-primary/10">
                      {getCategoryIcon(place.category)}
                    </div>
                    
                    <div className="flex-1">
                      <div className="font-medium">{place.name}</div>
                      <div className="text-sm text-muted-foreground flex items-center gap-2">
                        <span>{place.distance}km away</span>
                        <span>•</span>
                        <div className="flex items-center gap-1">
                          <Target className="h-3 w-3" />
                          <span>{place.rating}</span>
                        </div>
                        <span>•</span>
                        <Badge
                          variant={place.isOpen ? "secondary" : "outline"}
                          className="text-xs"
                        >
                          {place.isOpen ? "Open" : "Closed"}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      const url = `https://www.google.com/maps/search/${encodeURIComponent(place.name + " " + place.address)}`;
                      window.open(url, '_blank');
                    }}
                  >
                    <Navigation className="h-4 w-4" />
                  </Button>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}