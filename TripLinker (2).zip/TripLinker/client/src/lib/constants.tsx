export const APP_CONFIG = {
  name: "TripLinker",
  description: "Your AI-powered travel companion",
  version: "1.0.0",
};

export const API_ENDPOINTS = {
  destinations: "/api/destinations",
  guides: "/api/guides",
  trips: "/api/trips",
  chat: "/api/chat",
  aiChat: "/api/ai/chat",
  weather: "/api/weather",
  translate: "/api/translate",
  users: "/api/users",
};

export const LANGUAGES = [
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "hi", name: "हिंदी", flag: "🇮🇳" },
  { code: "es", name: "Español", flag: "🇪🇸" },
  { code: "fr", name: "Français", flag: "🇫🇷" },
  { code: "de", name: "Deutsch", flag: "🇩🇪" },
  { code: "ta", name: "தமிழ்", flag: "🇮🇳" },
  { code: "te", name: "తెలుగు", flag: "🇮🇳" },
  { code: "bn", name: "বাংলা", flag: "🇧🇩" },
  { code: "ml", name: "മലയാളം", flag: "🇮🇳" },
  { code: "kn", name: "ಕನ್ನಡ", flag: "🇮🇳" },
  { code: "ur", name: "اردو", flag: "🇵🇰" },
  { code: "pt", name: "Português", flag: "🇵🇹" },
];

export const DESTINATION_TAGS = [
  "Mountain",
  "Beach",
  "City",
  "Heritage",
  "Adventure",
  "Culture",
  "Wildlife",
  "Spiritual",
  "Island",
  "Desert",
  "Lake",
  "Hill Station",
];

export const MOCK_STATS = {
  destinations: "2,500+",
  guides: "850+", 
  languages: "12",
  users: "45k+",
};
