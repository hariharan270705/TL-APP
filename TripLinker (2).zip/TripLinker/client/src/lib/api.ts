import { apiRequest } from "./queryClient";
import type { Destination, Guide, Trip, ChatMessage, User } from "@shared/schema";

export const api = {
  // Destinations
  destinations: {
    getAll: (filters?: { search?: string; tags?: string[] }) => {
      const params = new URLSearchParams();
      if (filters?.search) params.append("search", filters.search);
      if (filters?.tags) filters.tags.forEach(tag => params.append("tags", tag));
      
      return apiRequest("GET", `/api/destinations?${params.toString()}`);
    },
    getById: (id: string) => apiRequest("GET", `/api/destinations/${id}`),
    create: (data: any) => apiRequest("POST", "/api/destinations", data),
  },

  // Guides
  guides: {
    getAll: (filters?: { location?: string; language?: string; experience?: string }) => {
      const params = new URLSearchParams();
      if (filters?.location) params.append("location", filters.location);
      if (filters?.language) params.append("language", filters.language);
      if (filters?.experience) params.append("experience", filters.experience);
      
      return apiRequest("GET", `/api/guides?${params.toString()}`);
    },
    getById: (id: string) => apiRequest("GET", `/api/guides/${id}`),
    create: (data: any) => apiRequest("POST", "/api/guides", data),
    update: (id: string, data: any) => apiRequest("PATCH", `/api/guides/${id}`, data),
  },

  // Trips
  trips: {
    getByUser: (userId: string) => apiRequest("GET", `/api/trips?userId=${userId}`),
    getById: (id: string) => apiRequest("GET", `/api/trips/${id}`),
    create: (data: any) => apiRequest("POST", "/api/trips", data),
    update: (id: string, data: any) => apiRequest("PATCH", `/api/trips/${id}`, data),
  },

  // Chat
  chat: {
    getMessages: (userId: string) => apiRequest("GET", `/api/chat/${userId}`),
    sendMessage: (data: { userId: string; content: string; role: string }) => 
      apiRequest("POST", "/api/chat", data),
    sendAiMessage: (data: { message: string; userId: string }) =>
      apiRequest("POST", "/api/ai/chat", data),
  },

  // Users
  users: {
    getById: (id: string) => apiRequest("GET", `/api/users/${id}`),
    create: (data: any) => apiRequest("POST", "/api/users", data),
    update: (id: string, data: any) => apiRequest("PATCH", `/api/users/${id}`, data),
  },

  // Weather
  weather: {
    getByCoords: (lat: number, lon: number) => 
      apiRequest("GET", `/api/weather/${lat}/${lon}`),
  },

  // Translation
  translation: {
    translate: (data: { text: string; from?: string; to: string }) =>
      apiRequest("POST", "/api/translate", data),
  },
};
