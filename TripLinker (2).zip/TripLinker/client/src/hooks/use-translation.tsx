import { useState, useCallback } from "react";
import { apiRequest } from "@/lib/queryClient";

export interface Translation {
  original: string;
  translated: string;
  from: string;
  to: string;
}

export function useTranslation() {
  const [isLoading, setIsLoading] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState("en");

  const translate = useCallback(async (text: string, from: string = "auto", to: string = "en"): Promise<string> => {
    if (!text || from === to) return text;
    
    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/translate", { text, from, to });
      const data = await response.json();
      return data.translatedText || text;
    } catch (error) {
      console.error("Translation failed:", error);
      return text;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const languages = [
    { code: "en", name: "English", flag: "🇺🇸" },
    { code: "hi", name: "हिंदी", flag: "🇮🇳" },
    { code: "es", name: "Español", flag: "🇪🇸" },
    { code: "fr", name: "Français", flag: "🇫🇷" },
    { code: "de", name: "Deutsch", flag: "🇩🇪" },
    { code: "ta", name: "தமிழ்", flag: "🇮🇳" },
    { code: "te", name: "తెలుగు", flag: "🇮🇳" },
    { code: "bn", name: "বাংলা", flag: "🇧🇩" },
    { code: "ml", name: "മലയാളം", flag: "🇮🇳" },
    { code: "kn", name: "ಕನ್ನಡ", flag: "🇮🇳" },
    { code: "ur", name: "اردو", flag: "🇵🇰" },
    { code: "pt", name: "Português", flag: "🇵🇹" },
  ];

  return {
    translate,
    isLoading,
    currentLanguage,
    setCurrentLanguage,
    languages,
  };
}
