import { useTheme as useThemeInternal } from "@/components/theme-provider";

export function useTheme() {
  return useThemeInternal();
}
