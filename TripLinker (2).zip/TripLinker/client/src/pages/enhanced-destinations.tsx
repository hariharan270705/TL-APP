import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { 
  Search, 
  Filter, 
  MapPin, 
  Cloud, 
  Star, 
  Clock, 
  DollarSign,
  Camera,
  Navigation,
  Share2,
  Heart,
  Map,
  Calendar,
  Users,
  Thermometer,
  Wind,
  Droplets,
  Eye,
  Globe,
  Image,
  ExternalLink,
  Loader2,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { WeatherWidget } from "@/components/weather-widget";
import { useToast } from "@/hooks/use-toast";

interface TouristLocation {
  id: string;
  placeName: string;
  country: string;
  state: string;
  district: string;
  city: string;
  latitude: number;
  longitude: number;
  description: string;
  images: string[];
  category: string;
  weatherApiEndpoint: string;
  guideAvailable: boolean;
  aiSupport: boolean;
  rating: number;
  bestTimeToVisit: string;
  entryFee: string;
  openingHours: string;
  nearbyAttractions: string[];
  tags: string[];
}

interface WeatherData {
  location: string;
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  forecast: Array<{
    day: string;
    high: number;
    low: number;
    condition: string;
  }>;
}

export default function EnhancedDestinations() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  const [selectedCountry, setSelectedCountry] = useState("All Countries");
  const [selectedLocation, setSelectedLocation] = useState<TouristLocation | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [isGridView, setIsGridView] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [expandedCards, setExpandedCards] = useState<Set<string>>(new Set());
  const locationsPerPage = 12;
  
  const { toast } = useToast();

  // Fetch destinations with filters
  const { data: destinations = [], isLoading } = useQuery({
    queryKey: ['/api/destinations', selectedCategory, selectedCountry, searchQuery],
    queryFn: () => {
      const params = new URLSearchParams();
      if (selectedCategory !== "All Categories") params.append('category', selectedCategory);
      if (selectedCountry !== "All Countries") params.append('country', selectedCountry);
      if (searchQuery) params.append('search', searchQuery);
      
      return api.get(`/api/destinations?${params.toString()}`);
    }
  });

  // Fetch categories and countries
  const { data: categories = [] } = useQuery({
    queryKey: ['/api/destinations/categories'],
    queryFn: () => api.get('/api/destinations/categories')
  });

  const { data: countries = [] } = useQuery({
    queryKey: ['/api/destinations/countries'],
    queryFn: () => api.get('/api/destinations/countries')
  });

  // Fetch weather for selected location
  const { data: weatherData, isLoading: weatherLoading } = useQuery({
    queryKey: ['/api/destinations/weather', selectedLocation?.id],
    queryFn: () => selectedLocation ? api.get(`/api/destinations/${selectedLocation.id}/weather`) : null,
    enabled: !!selectedLocation
  });

  // Pagination calculations
  const totalPages = Math.ceil(destinations.length / locationsPerPage);
  const paginatedDestinations = destinations.slice(
    (currentPage - 1) * locationsPerPage,
    currentPage * locationsPerPage
  );

  // Handle navigation
  const handleNavigate = (location: TouristLocation) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${location.latitude},${location.longitude}`;
    window.open(url, '_blank');
    toast({
      title: "Navigation Opened",
      description: `Directions to ${location.placeName} opened in Google Maps`
    });
  };

  // Handle sharing
  const handleShare = async (location: TouristLocation) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: location.placeName,
          text: location.description,
          url: window.location.href
        });
      } catch (error) {
        console.log('Share cancelled');
      }
    } else {
      // Fallback to clipboard
      await navigator.clipboard.writeText(
        `Check out ${location.placeName}: ${location.description} - ${window.location.href}`
      );
      toast({
        title: "Link Copied",
        description: "Location details copied to clipboard"
      });
    }
  };

  // Handle favorites
  const handleFavorite = (locationId: string) => {
    setFavorites(prev => 
      prev.includes(locationId) 
        ? prev.filter(id => id !== locationId)
        : [...prev, locationId]
    );
    
    const action = favorites.includes(locationId) ? "removed from" : "added to";
    toast({
      title: `Favorites Updated`,
      description: `Location ${action} your favorites`
    });
  };

  // Toggle card expansion
  const toggleCardExpansion = (locationId: string) => {
    setExpandedCards(prev => {
      const newSet = new Set(prev);
      if (newSet.has(locationId)) {
        newSet.delete(locationId);
      } else {
        newSet.add(locationId);
      }
      return newSet;
    });
  };

  const LocationCard = ({ location }: { location: TouristLocation }) => {
    const isExpanded = expandedCards.has(location.id);
    const isFavorite = favorites.includes(location.id);

    return (
      <motion.div
        layout
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.3 }}
        className="h-full"
      >
        <Card className="h-full flex flex-col overflow-hidden hover:shadow-lg transition-all duration-300 group">
          {/* Image Section */}
          <div className="relative h-48 overflow-hidden">
            <img
              src={location.images[0] || "/placeholder-destination.jpg"}
              alt={location.placeName}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            
            {/* Overlay Info */}
            <div className="absolute top-3 left-3 flex gap-2">
              <Badge variant="secondary" className="bg-white/90 text-black">
                {location.category}
              </Badge>
              {location.guideAvailable && (
                <Badge variant="secondary" className="bg-green-500/90 text-white">
                  <Users className="h-3 w-3 mr-1" />
                  Guide Available
                </Badge>
              )}
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              className="absolute top-3 right-3 bg-white/20 hover:bg-white/30"
              onClick={() => handleFavorite(location.id)}
            >
              <Heart className={`h-4 w-4 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-white'}`} />
            </Button>

            {/* Rating */}
            <div className="absolute bottom-3 left-3 flex items-center gap-1 bg-white/90 rounded-full px-2 py-1">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span className="text-sm font-medium">{location.rating}</span>
            </div>
          </div>

          <CardHeader className="pb-3">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <CardTitle className="text-xl font-bold">{location.placeName}</CardTitle>
                <CardDescription className="flex items-center gap-1 mt-1">
                  <MapPin className="h-4 w-4" />
                  {location.city}, {location.state}, {location.country}
                </CardDescription>
              </div>
            </div>
          </CardHeader>

          <CardContent className="flex-1 flex flex-col">
            {/* Description */}
            <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
              {location.description}
            </p>

            {/* Expandable Details */}
            <AnimatePresence>
              {isExpanded && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-3 mb-4"
                >
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-blue-500" />
                      <div>
                        <div className="font-medium">Best Time</div>
                        <div className="text-muted-foreground">{location.bestTimeToVisit}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4 text-green-500" />
                      <div>
                        <div className="font-medium">Entry Fee</div>
                        <div className="text-muted-foreground">{location.entryFee}</div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-orange-500" />
                    <div>
                      <div className="font-medium">Opening Hours</div>
                      <div className="text-muted-foreground">{location.openingHours}</div>
                    </div>
                  </div>

                  {location.nearbyAttractions.length > 0 && (
                    <div>
                      <div className="font-medium text-sm mb-2">Nearby Attractions</div>
                      <div className="flex flex-wrap gap-1">
                        {location.nearbyAttractions.slice(0, 3).map((attraction, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {attraction}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {location.tags.length > 0 && (
                    <div>
                      <div className="font-medium text-sm mb-2">Tags</div>
                      <div className="flex flex-wrap gap-1">
                        {location.tags.map((tag, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Action Buttons */}
            <div className="mt-auto space-y-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => toggleCardExpansion(location.id)}
                className="w-full"
              >
                {isExpanded ? (
                  <>
                    <ChevronUp className="h-4 w-4 mr-2" />
                    Show Less
                  </>
                ) : (
                  <>
                    <ChevronDown className="h-4 w-4 mr-2" />
                    View Details
                  </>
                )}
              </Button>

              <div className="grid grid-cols-3 gap-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button 
                      variant="default" 
                      size="sm"
                      onClick={() => setSelectedLocation(location)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </DialogTrigger>
                  <LocationDetailModal location={location} weather={weatherData} />
                </Dialog>

                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleNavigate(location)}
                >
                  <Navigation className="h-4 w-4" />
                </Button>

                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleShare(location)}
                >
                  <Share2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  };

  const LocationDetailModal = ({ location, weather }: { location: TouristLocation | null, weather?: WeatherData }) => {
    if (!location) return null;

    return (
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">{location.placeName}</DialogTitle>
        </DialogHeader>
        
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="gallery">Gallery</TabsTrigger>
            <TabsTrigger value="weather">Weather</TabsTrigger>
            <TabsTrigger value="planning">AI Planning</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <img
                  src={location.images[0]}
                  alt={location.placeName}
                  className="w-full h-64 object-cover rounded-lg"
                />
              </div>
              
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Location Details</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-blue-500" />
                      <span>{location.city}, {location.state}, {location.country}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span>{location.rating} / 5.0 Rating</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-green-500" />
                      <span>Best Time: {location.bestTimeToVisit}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-2">Practical Information</h3>
                  <div className="space-y-2 text-sm">
                    <div><strong>Entry Fee:</strong> {location.entryFee}</div>
                    <div><strong>Opening Hours:</strong> {location.openingHours}</div>
                    <div><strong>Category:</strong> {location.category}</div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-2">Description</h3>
              <p className="text-muted-foreground">{location.description}</p>
            </div>

            {location.nearbyAttractions.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-2">Nearby Attractions</h3>
                <div className="flex flex-wrap gap-2">
                  {location.nearbyAttractions.map((attraction, idx) => (
                    <Badge key={idx} variant="secondary">
                      {attraction}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="gallery">
            <div className="grid md:grid-cols-2 gap-4">
              {location.images.map((image, idx) => (
                <img
                  key={idx}
                  src={image}
                  alt={`${location.placeName} ${idx + 1}`}
                  className="w-full h-64 object-cover rounded-lg"
                />
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="weather">
            <WeatherWidget location={location.placeName} />
          </TabsContent>
          
          <TabsContent value="planning">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">AI Trip Planning</h3>
              <p className="text-muted-foreground">
                Get personalized trip recommendations for {location.placeName} based on your preferences.
              </p>
              <Button className="w-full">
                Generate AI Itinerary for {location.placeName}
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="text-center">
              <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4 text-primary" />
              <h3 className="text-lg font-semibold mb-2">Loading Amazing Destinations</h3>
              <p className="text-muted-foreground">Discovering 200+ incredible places around the world...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Discover Amazing Destinations
            </h1>
            <p className="text-xl md:text-2xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Explore 200+ handpicked destinations worldwide with verified information, real-time weather, and local guides
            </p>
            <div className="flex items-center justify-center gap-4 text-sm">
              <div className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                <span>{destinations.length} Destinations</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                <span>Local Guides Available</span>
              </div>
              <div className="flex items-center gap-2">
                <Cloud className="h-5 w-5" />
                <span>Real-time Weather</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-white dark:bg-gray-900 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search destinations, countries, or landmarks..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Select Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedCountry} onValueChange={setSelectedCountry}>
              <SelectTrigger>
                <SelectValue placeholder="Select Country" />
              </SelectTrigger>
              <SelectContent>
                {countries.map((country) => (
                  <SelectItem key={country} value={country}>
                    {country}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between mt-4">
            <div className="text-sm text-muted-foreground">
              Showing {paginatedDestinations.length} of {destinations.length} destinations
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">View:</span>
              <Button
                variant={isGridView ? "default" : "outline"}
                size="sm"
                onClick={() => setIsGridView(true)}
              >
                Grid
              </Button>
              <Button
                variant={!isGridView ? "default" : "outline"}
                size="sm"
                onClick={() => setIsGridView(false)}
              >
                List
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Destinations Grid */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {paginatedDestinations.length === 0 ? (
            <div className="text-center py-16">
              <Map className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-xl font-semibold mb-2">No destinations found</h3>
              <p className="text-muted-foreground">Try adjusting your search or filter criteria</p>
            </div>
          ) : (
            <>
              <motion.div
                className={`grid gap-6 ${isGridView ? 'md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'}`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6 }}
              >
                <AnimatePresence mode="popLayout">
                  {paginatedDestinations.map((location) => (
                    <LocationCard key={location.id} location={location} />
                  ))}
                </AnimatePresence>
              </motion.div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-2 mt-8">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    disabled={currentPage === 1}
                  >
                    Previous
                  </Button>
                  
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                    <Button
                      key={page}
                      variant={currentPage === page ? "default" : "outline"}
                      onClick={() => setCurrentPage(page)}
                      className="w-10"
                    >
                      {page}
                    </Button>
                  ))}
                  
                  <Button
                    variant="outline"
                    onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                    disabled={currentPage === totalPages}
                  >
                    Next
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </section>
    </div>
  );
}