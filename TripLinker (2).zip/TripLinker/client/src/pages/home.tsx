import { motion } from "framer-motion";
import { Navigation } from "@/components/navigation";
import { Hero } from "@/components/hero";
import { DestinationCard } from "@/components/destination-card";
import { GuideCard } from "@/components/guide-card";
import { AiChat } from "@/components/ai-chat";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Search, Filter, Bot, Shield, MapPin, Globe, Upload, Bell, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import type { Destination, Guide } from "@shared/schema";

export default function Home() {
  // Fetch featured destinations
  const { data: destinations = [], isLoading: destinationsLoading } = useQuery({
    queryKey: ["/api/destinations"],
    queryFn: () => api.destinations.getAll().then(res => res.json()),
  });

  // Fetch featured guides
  const { data: guides = [], isLoading: guidesLoading } = useQuery({
    queryKey: ["/api/guides"],
    queryFn: () => api.guides.getAll().then(res => res.json()),
  });

  const features = [
    {
      icon: Bot,
      title: "AI-Powered Planning",
      description: "Let our advanced AI analyze your preferences and create personalized itineraries with photo uploads and voice commands.",
      gradient: "from-primary-50 to-primary-100 dark:from-primary-900/20 dark:to-primary-800/20",
      iconBg: "bg-primary",
    },
    {
      icon: MapPin,
      title: "Real-time Location",
      description: "Stay connected with live GPS tracking, weather updates, and instant notifications for a seamless travel experience.",
      gradient: "from-secondary-50 to-secondary-100 dark:from-secondary-900/20 dark:to-secondary-800/20",
      iconBg: "bg-secondary",
    },
    {
      icon: Globe,
      title: "Multi-language Support",
      description: "Break language barriers with real-time translation, voice assistance, and support for 12+ regional languages.",
      gradient: "from-accent-50 to-accent-100 dark:from-accent-900/20 dark:to-accent-800/20",
      iconBg: "bg-accent",
    },
    {
      icon: Shield,
      title: "Verified Guides",
      description: "Connect with thoroughly verified local experts through biometric authentication and government ID verification.",
      gradient: "from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20",
      iconBg: "bg-purple-500",
    },
    {
      icon: Upload,
      title: "Smart File Analysis",
      description: "Upload photos and videos for AI-powered destination analysis and personalized route recommendations.",
      gradient: "from-pink-50 to-pink-100 dark:from-pink-900/20 dark:to-pink-800/20",
      iconBg: "bg-pink-500",
    },
    {
      icon: Bell,
      title: "Smart Notifications",
      description: "Receive timely updates via email and SMS for weather alerts, trip reminders, and guide confirmations.",
      gradient: "from-indigo-50 to-indigo-100 dark:from-indigo-900/20 dark:to-indigo-800/20",
      iconBg: "bg-indigo-500",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <Hero />

      {/* Destinations Section */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              Popular Destinations
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Explore breathtaking destinations with real-time weather, local guides, and AI-powered recommendations
            </p>
          </motion.div>

          {/* Search and Filters */}
          <motion.div
            className="mb-12 flex flex-col md:flex-row gap-4 justify-center items-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <div className="relative w-full md:w-96">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input 
                placeholder="Search destinations..." 
                className="pl-12"
              />
            </div>
            <div className="flex gap-2">
              <Button variant="default">All</Button>
              <Button variant="outline">Mountains</Button>
              <Button variant="outline">Beaches</Button>
              <Button variant="outline">Cities</Button>
            </div>
          </motion.div>

          {/* Destinations Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {destinationsLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <Card key={i} className="h-96">
                  <CardContent className="p-0">
                    <div className="w-full h-48 bg-muted animate-pulse" />
                    <div className="p-6 space-y-3">
                      <div className="h-6 bg-muted animate-pulse rounded" />
                      <div className="h-4 bg-muted animate-pulse rounded w-3/4" />
                      <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              destinations.slice(0, 3).map((destination: Destination, index: number) => (
                <DestinationCard key={destination.id} destination={destination} index={index} />
              ))
            )}
          </div>

          <motion.div
            className="text-center"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <Link href="/destinations">
              <Button size="lg" className="bg-secondary hover:bg-secondary/90">
                View All Destinations
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* AI Planner Section */}
      <section className="py-20 gradient-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              AI-Powered Trip Planner
            </h2>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Upload photos, describe your interests, and let our AI create personalized travel experiences
            </p>
          </motion.div>

          <AiChat />
        </div>
      </section>

      {/* Guides Section */}
      <section className="py-20 bg-muted/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              Connect with Local Guides
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Meet verified local experts who will make your journey unforgettable with authentic experiences
            </p>
          </motion.div>

          {/* Guide Search Filters */}
          <motion.div
            className="mb-12 bg-card rounded-2xl p-6 shadow-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <div className="grid md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Location</label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select destination" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="leh">Leh Ladakh</SelectItem>
                    <SelectItem value="goa">Goa</SelectItem>
                    <SelectItem value="rajasthan">Rajasthan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Language</label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Any language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="english">English</SelectItem>
                    <SelectItem value="hindi">Hindi</SelectItem>
                    <SelectItem value="local">Local dialect</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Experience</label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Any experience" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1-3">1-3 years</SelectItem>
                    <SelectItem value="3-5">3-5 years</SelectItem>
                    <SelectItem value="5+">5+ years</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button className="w-full">
                  <Search className="mr-2 h-4 w-4" />
                  Search Guides
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Guides Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {guidesLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <Card key={i} className="h-96">
                  <CardContent className="p-0">
                    <div className="w-full h-48 bg-muted animate-pulse" />
                    <div className="p-6 space-y-3">
                      <div className="h-6 bg-muted animate-pulse rounded" />
                      <div className="h-4 bg-muted animate-pulse rounded w-3/4" />
                      <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              guides.slice(0, 3).map((guide: Guide, index: number) => (
                <GuideCard key={guide.id} guide={guide} index={index} />
              ))
            )}
          </div>

          <motion.div
            className="text-center"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <Link href="/guides">
              <Button size="lg" className="bg-accent hover:bg-accent/90 mr-4">
                View All Guides
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Button size="lg" variant="outline">
              Become a Guide
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              Why Choose TripLinker?
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Experience travel like never before with our cutting-edge features designed for modern explorers
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                className={`text-center p-8 bg-gradient-to-br ${feature.gradient} rounded-2xl hover-lift`}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.02 }}
              >
                <div className={`w-16 h-16 ${feature.iconBg} rounded-2xl flex items-center justify-center mx-auto mb-6 animate-float`}>
                  <feature.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-4">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-6">
                <div className="w-10 h-10 gradient-bg rounded-xl flex items-center justify-center">
                  <Bot className="text-white text-lg" />
                </div>
                <span className="text-xl font-bold">TripLinker</span>
              </div>
              <p className="text-gray-400 mb-6">Your AI-powered travel companion for unforgettable journeys with local expertise.</p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-6">For Travelers</h3>
              <ul className="space-y-3 text-gray-400">
                <li><Link href="/destinations" className="hover:text-white transition-colors">Browse Destinations</Link></li>
                <li><Link href="/ai-planner" className="hover:text-white transition-colors">AI Trip Planner</Link></li>
                <li><Link href="/guides" className="hover:text-white transition-colors">Find Local Guides</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-6">For Guides</h3>
              <ul className="space-y-3 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Become a Guide</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Verification Process</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Guide Dashboard</a></li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-6">Support</h3>
              <ul className="space-y-3 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">© 2025 TripLinker. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <span className="text-sm text-gray-400">Made with ❤️ for travelers</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
