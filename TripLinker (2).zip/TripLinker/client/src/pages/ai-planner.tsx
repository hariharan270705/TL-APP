import { useState } from "react";
import { motion } from "framer-motion";
import { Navigation } from "@/components/navigation";
import { LocationTracker } from "@/components/location-tracker";
import { VoiceAssistant } from "@/components/voice-assistant";
import { AiChat } from "@/components/ai-chat";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { 
  Bot, 
  Upload, 
  Mic, 
  MapPin, 
  Calendar, 
  Cloud, 
  Share2, 
  Camera, 
  Video, 
  FileText,
  Plane,
  Hotel,
  Mountain,
  Utensils,
  Clock,
  DollarSign,
  Users,
  Star
} from "lucide-react";
import type { Trip, Destination } from "@shared/schema";

export default function AiPlanner() {
  const [activeTab, setActiveTab] = useState("chat");
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);

  // Fetch user's trips (using demo user for now)
  const { data: trips = [], isLoading: tripsLoading } = useQuery({
    queryKey: ["/api/trips", "demo-user"],
    queryFn: () => api.trips.getByUser("demo-user").then(res => res.json()),
  });

  // Fetch featured destinations for recommendations
  const { data: destinations = [] } = useQuery({
    queryKey: ["/api/destinations"],
    queryFn: () => api.destinations.getAll().then(res => res.json()),
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    setIsUploading(true);
    setUploadProgress(0);

    // Simulate file upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          return 100;
        }
        return prev + 10;
      });
    }, 200);

    // Handle file upload logic here
    console.log("Uploading files:", files);
  };

  const planningSteps = [
    { icon: Upload, title: "Upload Photos", description: "Share photos of places you'd like to visit", completed: false },
    { icon: Bot, title: "AI Analysis", description: "Our AI analyzes your preferences", completed: false },
    { icon: MapPin, title: "Route Planning", description: "Generate optimized travel routes", completed: false },
    { icon: Calendar, title: "Schedule", description: "Create detailed day-by-day itinerary", completed: false },
    { icon: Share2, title: "Share & Book", description: "Share with guides and book services", completed: false },
  ];

  const quickPrompts = [
    "Plan a 7-day trip to Rajasthan with heritage sites",
    "I want to explore mountain destinations in North India",
    "Suggest beach destinations for a romantic getaway",
    "Create an adventure sports itinerary for Himachal Pradesh",
    "Plan a cultural tour of South India temples",
    "Recommend wildlife safari destinations"
  ];

  const aiFeatures = [
    { icon: Camera, title: "Photo Analysis", description: "Upload photos and get instant destination suggestions" },
    { icon: Mic, title: "Voice Planning", description: "Speak your travel preferences naturally" },
    { icon: Cloud, title: "Weather Integration", description: "Real-time weather data for optimal planning" },
    { icon: MapPin, title: "Route Optimization", description: "Smart routing based on distance and attractions" },
    { icon: Utensils, title: "Local Cuisine", description: "Food recommendations and restaurant suggestions" },
    { icon: Hotel, title: "Accommodation", description: "Find the perfect stay for your budget" }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Header */}
      <section className="pt-24 pb-12 gradient-bg relative overflow-hidden">
        {/* Floating elements */}
        <div className="absolute inset-0 opacity-10">
          <Plane className="absolute top-20 left-10 h-16 w-16 text-white animate-float" />
          <Mountain className="absolute top-40 right-20 h-12 w-12 text-white animate-bounce-slow" />
          <Camera className="absolute bottom-32 left-20 h-14 w-14 text-white animate-float animation-delay-400" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              AI Trip Planner
            </h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Upload photos, describe your interests, and let our AI create personalized travel experiences tailored just for you
            </p>
          </motion.div>

          {/* Planning Steps */}
          <motion.div
            className="grid md:grid-cols-5 gap-4 mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {planningSteps.map((step, index) => (
              <div key={step.title} className="text-center">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 ${
                  step.completed ? 'bg-secondary' : 'bg-white/20'
                }`}>
                  <step.icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-sm font-semibold text-white mb-1">{step.title}</h3>
                <p className="text-xs text-white/70">{step.description}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
            <TabsList className="grid w-full grid-cols-6 lg:w-auto lg:grid-cols-6">
              <TabsTrigger value="chat" className="flex items-center gap-2">
                <Bot className="h-4 w-4" />
                AI Chat
              </TabsTrigger>
              <TabsTrigger value="upload" className="flex items-center gap-2">
                <Upload className="h-4 w-4" />
                Upload Media
              </TabsTrigger>
              <TabsTrigger value="trips" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                My Trips
              </TabsTrigger>
              <TabsTrigger value="location" className="flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                Location
              </TabsTrigger>
              <TabsTrigger value="voice" className="flex items-center gap-2">
                <Mic className="h-4 w-4" />
                Voice
              </TabsTrigger>
              <TabsTrigger value="insights" className="flex items-center gap-2">
                <Star className="h-4 w-4" />
                AI Insights
              </TabsTrigger>
            </TabsList>

            <TabsContent value="chat" className="space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <AiChat userId="demo-user" />
              </motion.div>

              {/* Quick Prompts */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h3 className="text-xl font-bold text-foreground mb-4">Try these popular trip ideas:</h3>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {quickPrompts.map((prompt, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="justify-start text-left h-auto p-4"
                      onClick={() => console.log("Selected prompt:", prompt)}
                    >
                      <Bot className="h-4 w-4 mr-2 flex-shrink-0" />
                      <span className="text-sm">{prompt}</span>
                    </Button>
                  ))}
                </div>
              </motion.div>
            </TabsContent>

            <TabsContent value="upload" className="space-y-8">
              <motion.div
                className="grid lg:grid-cols-2 gap-8"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                {/* File Upload Area */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Upload className="h-5 w-5" />
                      Upload Travel Media
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="border-2 border-dashed border-muted-foreground/25 rounded-xl p-8 text-center hover:border-primary/50 transition-colors">
                      <input
                        type="file"
                        multiple
                        accept="image/*,video/*"
                        onChange={handleFileUpload}
                        className="hidden"
                        id="file-upload"
                      />
                      <label htmlFor="file-upload" className="cursor-pointer">
                        <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-lg font-semibold text-foreground mb-2">
                          Drop your photos and videos here
                        </h3>
                        <p className="text-muted-foreground mb-4">
                          JPG, PNG, MP4 up to 10MB each
                        </p>
                        <Button>Browse Files</Button>
                      </label>
                    </div>

                    {isUploading && (
                      <div className="mt-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-muted-foreground">Uploading...</span>
                          <span className="text-sm text-muted-foreground">{uploadProgress}%</span>
                        </div>
                        <Progress value={uploadProgress} className="w-full" />
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* AI Analysis Features */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Bot className="h-5 w-5" />
                      AI Analysis Features
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {aiFeatures.map((feature, index) => (
                        <div key={feature.title} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors">
                          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center flex-shrink-0">
                            <feature.icon className="h-4 w-4 text-primary-foreground" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-foreground">{feature.title}</h4>
                            <p className="text-sm text-muted-foreground">{feature.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            <TabsContent value="trips" className="space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-foreground">My Travel Plans</h2>
                  <Button>
                    <Calendar className="h-4 w-4 mr-2" />
                    Create New Trip
                  </Button>
                </div>

                {tripsLoading ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <Card key={i}>
                        <CardContent className="p-6">
                          <div className="space-y-3">
                            <div className="h-6 bg-muted animate-pulse rounded" />
                            <div className="h-4 bg-muted animate-pulse rounded w-3/4" />
                            <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : trips.length > 0 ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {trips.map((trip: Trip) => (
                      <Card key={trip.id} className="hover-lift">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between mb-3">
                            <h3 className="font-bold text-foreground">{trip.title}</h3>
                            <Badge variant={trip.status === "completed" ? "default" : "secondary"}>
                              {trip.status}
                            </Badge>
                          </div>
                          <p className="text-muted-foreground text-sm mb-4">{trip.description}</p>
                          <div className="space-y-2 text-xs text-muted-foreground">
                            <div className="flex items-center gap-2">
                              <Clock className="h-3 w-3" />
                              <span>
                                {trip.startDate && new Date(trip.startDate).toLocaleDateString()} - 
                                {trip.endDate && new Date(trip.endDate).toLocaleDateString()}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="h-3 w-3" />
                              <span>{trip.destinations?.length || 0} destinations</span>
                            </div>
                          </div>
                          <Button className="w-full mt-4" size="sm">
                            View Details
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card>
                    <CardContent className="p-12 text-center">
                      <Calendar className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-xl font-bold text-foreground mb-2">No trips planned yet</h3>
                      <p className="text-muted-foreground mb-6">
                        Start planning your first trip with our AI assistant
                      </p>
                      <Button onClick={() => setActiveTab("chat")}>
                        <Bot className="h-4 w-4 mr-2" />
                        Start Planning
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </motion.div>
            </TabsContent>

            <TabsContent value="location" className="space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <LocationTracker />
              </motion.div>
            </TabsContent>

            <TabsContent value="voice" className="space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <VoiceAssistant 
                  onTranslation={(original, translated, targetLang) => {
                    // Show translation result
                    console.log(`Translation: "${original}" → "${translated}" (${targetLang})`);
                  }}
                  onVoiceCommand={(command) => {
                    // Process voice command
                    console.log("Voice command received:", command);
                  }}
                />
              </motion.div>
            </TabsContent>

            <TabsContent value="insights" className="space-y-8">
              <motion.div
                className="grid lg:grid-cols-2 gap-8"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                {/* AI Recommendations */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Star className="h-5 w-5" />
                      AI Recommendations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {destinations.slice(0, 3).map((destination: Destination) => (
                        <div key={destination.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                          <img
                            src={destination.images?.[0] || "https://images.unsplash.com/photo-1506905925346-21bda4d32df4"}
                            alt={destination.name}
                            className="w-12 h-12 rounded-lg object-cover"
                          />
                          <div className="flex-1">
                            <h4 className="font-semibold text-foreground">{destination.name}</h4>
                            <p className="text-sm text-muted-foreground">{destination.state}, {destination.country}</p>
                            <div className="flex items-center gap-1 mt-1">
                              <Star className="h-3 w-3 text-yellow-500 fill-current" />
                              <span className="text-xs">{destination.rating}</span>
                            </div>
                          </div>
                          <Button size="sm" variant="outline">Explore</Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Travel Statistics */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      Your Travel Profile
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-foreground">{trips.length}</div>
                        <div className="text-sm text-muted-foreground">Trips Planned</div>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Adventure</span>
                            <span>75%</span>
                          </div>
                          <Progress value={75} />
                        </div>
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Culture</span>
                            <span>60%</span>
                          </div>
                          <Progress value={60} />
                        </div>
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Relaxation</span>
                            <span>45%</span>
                          </div>
                          <Progress value={45} />
                        </div>
                      </div>

                      <div className="pt-4 border-t">
                        <h4 className="font-semibold text-foreground mb-2">Preferred Destinations</h4>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="secondary">Mountains</Badge>
                          <Badge variant="secondary">Heritage Sites</Badge>
                          <Badge variant="secondary">Adventure Sports</Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  );
}
