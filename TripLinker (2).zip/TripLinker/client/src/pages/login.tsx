import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { Navigation } from "@/components/navigation";
import { 
  User, 
  Users, 
  Shield, 
  Eye, 
  EyeOff, 
  Upload, 
  Fingerprint,
  CheckCircle,
  AlertCircle,
  Phone,
  Mail,
  Chrome,
  Facebook,
  Loader2
} from "lucide-react";

export default function LoginPage() {
  const [activeTab, setActiveTab] = useState("tourist");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [verificationStep, setVerificationStep] = useState(1);
  const [uploadedDocs, setUploadedDocs] = useState<string[]>([]);
  const { toast } = useToast();

  // Tourist Login Form
  const [touristForm, setTouristForm] = useState({
    email: "",
    password: "",
    phone: "",
    otp: ""
  });

  // Guide Registration Form
  const [guideForm, setGuideForm] = useState({
    email: "",
    password: "",
    name: "",
    phone: "",
    aadhaar: "",
    pan: "",
    voterID: "",
    drivingLicense: "",
    documents: [] as File[]
  });

  const handleTouristLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      // Simulate login process
      await new Promise(resolve => setTimeout(resolve, 2000));
      toast({
        title: "Login Successful!",
        description: "Welcome back to TripLinker",
      });
      // Redirect to tourist dashboard
      window.location.href = "/dashboard/tourist";
    } catch (error) {
      toast({
        title: "Login Failed",
        description: "Please check your credentials and try again",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleGuideRegistration = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      // Simulate registration process
      await new Promise(resolve => setTimeout(resolve, 2000));
      toast({
        title: "Registration Submitted!",
        description: "Your profile is under admin verification. You'll be notified within 24-48 hours.",
      });
      setVerificationStep(2);
    } catch (error) {
      toast({
        title: "Registration Failed",
        description: "Please check all fields and try again",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDocumentUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      setUploadedDocs(prev => [...prev, ...files.map(f => f.name)]);
      setGuideForm(prev => ({ ...prev, documents: [...prev.documents, ...files] }));
      toast({
        title: "Documents Uploaded",
        description: `${files.length} document(s) uploaded successfully`,
      });
    }
  };

  const handleBiometricAuth = async () => {
    setIsLoading(true);
    try {
      // Check if WebAuthn is supported
      if (!navigator.credentials) {
        throw new Error("WebAuthn not supported");
      }
      
      // Simulate biometric authentication
      await new Promise(resolve => setTimeout(resolve, 3000));
      toast({
        title: "Biometric Verification Complete",
        description: "Face and fingerprint authentication successful",
      });
      setVerificationStep(3);
    } catch (error) {
      toast({
        title: "Biometric Authentication Failed",
        description: "Please ensure your device supports biometric authentication",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-blue-900 dark:to-indigo-900">
      <Navigation />
      
      <div className="pt-24 pb-12 px-4 sm:px-6 lg:px-8">
        <motion.div
          className="max-w-md mx-auto"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="text-center mb-8">
            <motion.h1 
              className="text-3xl font-bold text-foreground mb-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              Welcome to TripLinker
            </motion.h1>
            <p className="text-muted-foreground">
              Your AI-powered travel companion
            </p>
          </div>

          <Card className="backdrop-blur-sm bg-white/80 dark:bg-gray-800/80 border-0 shadow-2xl">
            <CardHeader>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="tourist" className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Tourist
                  </TabsTrigger>
                  <TabsTrigger value="guide" className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Guide
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </CardHeader>

            <CardContent>
              <Tabs value={activeTab}>
                {/* Tourist Login */}
                <TabsContent value="tourist" className="space-y-6">
                  <div className="text-center mb-6">
                    <h2 className="text-xl font-semibold text-foreground">Tourist Login</h2>
                    <p className="text-sm text-muted-foreground mt-1">
                      Explore destinations with AI assistance
                    </p>
                  </div>

                  {/* Social Login Options */}
                  <div className="space-y-3">
                    <Button variant="outline" className="w-full" onClick={() => toast({ title: "Google Login", description: "Feature coming soon!" })}>
                      <Chrome className="h-4 w-4 mr-2" />
                      Continue with Google
                    </Button>
                    <Button variant="outline" className="w-full" onClick={() => toast({ title: "Facebook Login", description: "Feature coming soon!" })}>
                      <Facebook className="h-4 w-4 mr-2" />
                      Continue with Facebook
                    </Button>
                  </div>

                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-background px-2 text-muted-foreground">Or continue with email</span>
                    </div>
                  </div>

                  <form onSubmit={handleTouristLogin} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="tourist-email">Email</Label>
                      <Input
                        id="tourist-email"
                        type="email"
                        placeholder="your.email@example.com"
                        value={touristForm.email}
                        onChange={(e) => setTouristForm(prev => ({ ...prev, email: e.target.value }))}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="tourist-password">Password</Label>
                      <div className="relative">
                        <Input
                          id="tourist-password"
                          type={showPassword ? "text" : "password"}
                          placeholder="Enter your password"
                          value={touristForm.password}
                          onChange={(e) => setTouristForm(prev => ({ ...prev, password: e.target.value }))}
                          required
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="tourist-phone">Phone Number (for OTP)</Label>
                      <Input
                        id="tourist-phone"
                        type="tel"
                        placeholder="+91 98765 43210"
                        value={touristForm.phone}
                        onChange={(e) => setTouristForm(prev => ({ ...prev, phone: e.target.value }))}
                        required
                      />
                    </div>

                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Logging in...
                        </>
                      ) : (
                        <>
                          <Mail className="h-4 w-4 mr-2" />
                          Login & Send OTP
                        </>
                      )}
                    </Button>
                  </form>
                </TabsContent>

                {/* Guide Registration */}
                <TabsContent value="guide" className="space-y-6">
                  <div className="text-center mb-6">
                    <h2 className="text-xl font-semibold text-foreground">Guide Registration</h2>
                    <div className="flex items-center justify-center gap-2 mt-2">
                      <Shield className="h-4 w-4 text-green-500" />
                      <span className="text-sm text-muted-foreground">High Security Verification</span>
                    </div>
                  </div>

                  {/* Verification Steps */}
                  <div className="flex items-center justify-between mb-6">
                    {[1, 2, 3].map((step) => (
                      <div key={step} className="flex items-center">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium ${
                          verificationStep >= step 
                            ? 'bg-green-500 text-white' 
                            : 'bg-muted text-muted-foreground'
                        }`}>
                          {verificationStep > step ? <CheckCircle className="h-4 w-4" /> : step}
                        </div>
                        {step < 3 && (
                          <div className={`w-16 h-0.5 mx-2 ${
                            verificationStep > step ? 'bg-green-500' : 'bg-muted'
                          }`} />
                        )}
                      </div>
                    ))}
                  </div>

                  {verificationStep === 1 && (
                    <form onSubmit={handleGuideRegistration} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="guide-name">Full Name</Label>
                          <Input
                            id="guide-name"
                            placeholder="John Doe"
                            value={guideForm.name}
                            onChange={(e) => setGuideForm(prev => ({ ...prev, name: e.target.value }))}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="guide-phone">Phone</Label>
                          <Input
                            id="guide-phone"
                            type="tel"
                            placeholder="+91 98765 43210"
                            value={guideForm.phone}
                            onChange={(e) => setGuideForm(prev => ({ ...prev, phone: e.target.value }))}
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="guide-email">Email</Label>
                        <Input
                          id="guide-email"
                          type="email"
                          placeholder="guide@example.com"
                          value={guideForm.email}
                          onChange={(e) => setGuideForm(prev => ({ ...prev, email: e.target.value }))}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="guide-password">Password</Label>
                        <Input
                          id="guide-password"
                          type="password"
                          placeholder="Strong password"
                          value={guideForm.password}
                          onChange={(e) => setGuideForm(prev => ({ ...prev, password: e.target.value }))}
                          required
                        />
                      </div>

                      {/* Identity Documents */}
                      <div className="space-y-4">
                        <div className="flex items-center gap-2">
                          <Shield className="h-4 w-4 text-blue-500" />
                          <Label className="text-sm font-medium">Identity Verification</Label>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="aadhaar">Aadhaar Number</Label>
                            <Input
                              id="aadhaar"
                              placeholder="1234 5678 9012"
                              value={guideForm.aadhaar}
                              onChange={(e) => setGuideForm(prev => ({ ...prev, aadhaar: e.target.value }))}
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="pan">PAN Number</Label>
                            <Input
                              id="pan"
                              placeholder="ABCDE1234F"
                              value={guideForm.pan}
                              onChange={(e) => setGuideForm(prev => ({ ...prev, pan: e.target.value }))}
                              required
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="voter-id">Voter ID (Optional)</Label>
                            <Input
                              id="voter-id"
                              placeholder="ABC1234567"
                              value={guideForm.voterID}
                              onChange={(e) => setGuideForm(prev => ({ ...prev, voterID: e.target.value }))}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="driving-license">Driving License (Optional)</Label>
                            <Input
                              id="driving-license"
                              placeholder="DL123456789"
                              value={guideForm.drivingLicense}
                              onChange={(e) => setGuideForm(prev => ({ ...prev, drivingLicense: e.target.value }))}
                            />
                          </div>
                        </div>
                      </div>

                      {/* Document Upload */}
                      <div className="space-y-4">
                        <div className="flex items-center gap-2">
                          <Upload className="h-4 w-4 text-green-500" />
                          <Label className="text-sm font-medium">Upload Documents</Label>
                        </div>
                        
                        <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center">
                          <input
                            type="file"
                            multiple
                            accept="image/*,.pdf"
                            onChange={handleDocumentUpload}
                            className="hidden"
                            id="document-upload"
                          />
                          <Label htmlFor="document-upload" className="cursor-pointer">
                            <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                            <p className="text-sm text-muted-foreground">
                              Upload ID proofs, certificates, photos
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              PNG, JPG, PDF up to 10MB each
                            </p>
                          </Label>
                        </div>

                        {uploadedDocs.length > 0 && (
                          <div className="space-y-2">
                            <Label className="text-sm">Uploaded Documents:</Label>
                            <div className="space-y-1">
                              {uploadedDocs.map((doc, idx) => (
                                <div key={idx} className="flex items-center gap-2 text-sm">
                                  <CheckCircle className="h-4 w-4 text-green-500" />
                                  <span className="truncate">{doc}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      <Alert>
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>
                          All information will be verified by our admin team. False information may result in permanent account suspension.
                        </AlertDescription>
                      </Alert>

                      <Button type="submit" className="w-full" disabled={isLoading}>
                        {isLoading ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Submitting...
                          </>
                        ) : (
                          <>
                            <Shield className="h-4 w-4 mr-2" />
                            Submit for Verification
                          </>
                        )}
                      </Button>
                    </form>
                  )}

                  {verificationStep === 2 && (
                    <div className="space-y-6">
                      <div className="text-center">
                        <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                        <h3 className="text-lg font-semibold text-foreground mb-2">
                          Documents Submitted Successfully!
                        </h3>
                        <p className="text-sm text-muted-foreground mb-6">
                          Now let's set up biometric authentication for enhanced security
                        </p>
                      </div>

                      <div className="space-y-4">
                        <Alert>
                          <Fingerprint className="h-4 w-4" />
                          <AlertDescription>
                            Biometric authentication adds an extra layer of security to your guide account. This includes face recognition and fingerprint authentication.
                          </AlertDescription>
                        </Alert>

                        <Button onClick={handleBiometricAuth} className="w-full" disabled={isLoading}>
                          {isLoading ? (
                            <>
                              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                              Setting up biometrics...
                            </>
                          ) : (
                            <>
                              <Fingerprint className="h-4 w-4 mr-2" />
                              Setup Biometric Authentication
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  )}

                  {verificationStep === 3 && (
                    <div className="text-center space-y-6">
                      <CheckCircle className="h-16 w-16 text-green-500 mx-auto" />
                      <div>
                        <h3 className="text-lg font-semibold text-foreground mb-2">
                          Registration Complete!
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          Your guide profile is now under admin review. You'll receive an email notification within 24-48 hours once verified.
                        </p>
                      </div>
                      
                      <div className="space-y-2">
                        <Badge variant="secondary" className="mb-2">
                          Next Steps:
                        </Badge>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li>• Admin will verify your documents</li>
                          <li>• Background check will be performed</li>
                          <li>• You'll receive verification status via email</li>
                          <li>• Once approved, you can start offering guide services</li>
                        </ul>
                      </div>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}