import { useState } from "react";
import { motion } from "framer-motion";
import { Navigation } from "@/components/navigation";
import { GuideCard } from "@/components/guide-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Search, Filter, MapPin, Users, Star, CheckCircle } from "lucide-react";
import { LANGUAGES } from "@/lib/constants";
import type { Guide } from "@shared/schema";

export default function Guides() {
  const [searchQuery, setSearchQuery] = useState("");
  const [locationFilter, setLocationFilter] = useState("");
  const [languageFilter, setLanguageFilter] = useState("");
  const [experienceFilter, setExperienceFilter] = useState("");
  const [sortBy, setSortBy] = useState("rating");

  const { data: guides = [], isLoading } = useQuery({
    queryKey: ["/api/guides", { 
      location: locationFilter || undefined,
      language: languageFilter || undefined,
      experience: experienceFilter || undefined
    }],
    queryFn: () => api.guides.getAll({
      location: locationFilter && locationFilter !== "all" ? locationFilter : undefined,
      language: languageFilter && languageFilter !== "all" ? languageFilter : undefined,
      experience: experienceFilter && experienceFilter !== "all" ? experienceFilter : undefined
    }).then(res => res.json()),
  });

  // Filter guides by search query
  const filteredGuides = guides.filter((guide: Guide) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      guide.name.toLowerCase().includes(query) ||
      guide.location.toLowerCase().includes(query) ||
      guide.specialization?.toLowerCase().includes(query) ||
      guide.languages?.some(lang => lang.toLowerCase().includes(query))
    );
  });

  // Sort guides
  const sortedGuides = [...filteredGuides].sort((a: Guide, b: Guide) => {
    switch (sortBy) {
      case "rating":
        return (b.rating || 0) - (a.rating || 0);
      case "name":
        return a.name.localeCompare(b.name);
      case "experience":
        return (b.experience || 0) - (a.experience || 0);
      case "rate":
        return (a.rate || 0) - (b.rate || 0);
      default:
        return 0;
    }
  });

  const clearFilters = () => {
    setSearchQuery("");
    setLocationFilter("all");
    setLanguageFilter("all");
    setExperienceFilter("all");
  };

  const activeFilters = [
    locationFilter && `Location: ${locationFilter}`,
    languageFilter && `Language: ${languageFilter}`,
    experienceFilter && `Experience: ${experienceFilter}`,
  ].filter(Boolean);

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Header */}
      <section className="pt-24 pb-12 bg-gradient-to-b from-muted/50 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
              Local Guides
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Connect with verified local experts who will make your journey unforgettable with authentic experiences
            </p>
          </motion.div>

          {/* Search and Filters */}
          <motion.div
            className="bg-card rounded-2xl p-6 shadow-lg space-y-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {/* Search Bar */}
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input 
                  placeholder="Search guides by name, location, or specialization..." 
                  className="pl-12"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rating">Sort by Rating</SelectItem>
                  <SelectItem value="name">Sort by Name</SelectItem>
                  <SelectItem value="experience">Sort by Experience</SelectItem>
                  <SelectItem value="rate">Sort by Rate (Low to High)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Filter Controls */}
            <div className="grid md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Location</label>
                <Select value={locationFilter} onValueChange={setLocationFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="All locations" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All locations</SelectItem>
                    <SelectItem value="Leh">Leh Ladakh</SelectItem>
                    <SelectItem value="Jaipur">Jaipur, Rajasthan</SelectItem>
                    <SelectItem value="Port Blair">Port Blair, Andaman</SelectItem>
                    <SelectItem value="Goa">Goa</SelectItem>
                    <SelectItem value="Kerala">Kerala</SelectItem>
                    <SelectItem value="Himachal">Himachal Pradesh</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Language</label>
                <Select value={languageFilter} onValueChange={setLanguageFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Any language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Any language</SelectItem>
                    <SelectItem value="English">English</SelectItem>
                    <SelectItem value="Hindi">Hindi</SelectItem>
                    <SelectItem value="Tamil">Tamil</SelectItem>
                    <SelectItem value="Telugu">Telugu</SelectItem>
                    <SelectItem value="Malayalam">Malayalam</SelectItem>
                    <SelectItem value="Kannada">Kannada</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Experience</label>
                <Select value={experienceFilter} onValueChange={setExperienceFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Any experience" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Any experience</SelectItem>
                    <SelectItem value="1-3">1-3 years</SelectItem>
                    <SelectItem value="3-5">3-5 years</SelectItem>
                    <SelectItem value="5+">5+ years</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-end">
                <Button className="w-full" onClick={clearFilters} variant="outline">
                  <Filter className="mr-2 h-4 w-4" />
                  Clear Filters
                </Button>
              </div>
            </div>

            {/* Active Filters */}
            {activeFilters.length > 0 && (
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm text-muted-foreground">Active filters:</span>
                {activeFilters.map((filter, index) => (
                  <Badge key={index} variant="secondary">
                    {filter}
                  </Badge>
                ))}
              </div>
            )}
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-8 bg-muted/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <div>
              <div className="text-3xl font-bold text-foreground">{guides.length}</div>
              <div className="text-sm text-muted-foreground">Total Guides</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-foreground">
                {guides.filter((g: Guide) => g.verificationStatus === "verified").length}
              </div>
              <div className="text-sm text-muted-foreground">Verified Guides</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-foreground">
                {Math.round(guides.reduce((acc: number, g: Guide) => acc + g.rating, 0) / guides.length * 10) / 10 || 0}
              </div>
              <div className="text-sm text-muted-foreground">Average Rating</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-foreground">
                {new Set(guides.flatMap((g: Guide) => g.languages)).size}
              </div>
              <div className="text-sm text-muted-foreground">Languages Supported</div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Guides Grid */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {Array.from({ length: 6 }).map((_, i) => (
                <Card key={i} className="h-96">
                  <CardContent className="p-0">
                    <div className="w-full h-48 bg-muted animate-pulse" />
                    <div className="p-6 space-y-3">
                      <div className="h-6 bg-muted animate-pulse rounded" />
                      <div className="h-4 bg-muted animate-pulse rounded w-3/4" />
                      <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                      <div className="h-10 bg-muted animate-pulse rounded" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : sortedGuides.length > 0 ? (
            <motion.div
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              {sortedGuides.map((guide: Guide, index: number) => (
                <GuideCard key={guide.id} guide={guide} index={index} />
              ))}
            </motion.div>
          ) : (
            <motion.div
              className="text-center py-20"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Users className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-foreground mb-2">No guides found</h3>
              <p className="text-muted-foreground mb-6">
                Try adjusting your search criteria or explore different locations
              </p>
              <Button onClick={clearFilters}>
                Clear filters
              </Button>
            </motion.div>
          )}
        </div>
      </section>

      {/* Become a Guide CTA */}
      <section className="py-20 gradient-bg">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Become a Verified Guide
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Share your local expertise, connect with travelers from around the world, and earn income doing what you love
            </p>
            
            <div className="grid md:grid-cols-3 gap-6 mb-12">
              <div className="text-center">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Get Verified</h3>
                <p className="text-white/80 text-sm">Complete our verification process with government ID and biometric authentication</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Connect with Travelers</h3>
                <p className="text-white/80 text-sm">Meet amazing people from around the world and share your local knowledge</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Earn & Grow</h3>
                <p className="text-white/80 text-sm">Build your reputation, receive great reviews, and increase your earning potential</p>
              </div>
            </div>
            
            <Button size="lg" className="bg-secondary hover:bg-secondary/90 text-white font-semibold px-8 py-4">
              Start Your Guide Journey
            </Button>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
