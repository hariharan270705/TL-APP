# TripLinker

## Overview

TripLinker is a full-featured, multilingual travel assistant web application that connects tourists with local guides. The platform provides AI-powered trip planning, real-time location tracking, voice assistance, and comprehensive travel management features. Built as a modern full-stack application, it serves both tourists seeking personalized travel experiences and local guides offering their expertise.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React.js with TypeScript for type safety
- **Styling**: Tailwind CSS for utility-first styling with ShadCN UI component library
- **State Management**: TanStack Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Animations**: Framer Motion for smooth UI transitions and interactions
- **UI Components**: Radix UI primitives with custom styling for accessibility

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript for end-to-end type safety
- **API Design**: RESTful API with structured route handling
- **Storage**: In-memory storage with planned database integration
- **Development**: Hot module replacement with Vite in development mode

### Database Design
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema**: Shared schema definitions between client and server
- **Tables**: Users, destinations, guides, trips, and chat messages with proper relationships
- **Validation**: Zod schema validation for data integrity

### Authentication & Authorization
- **User Roles**: Tourist, guide, and admin with role-based access
- **Verification**: Multi-level verification system for guides including document upload
- **Session Management**: Planned integration with secure session handling

### Multilingual Support
- **Translation**: LibreTranslate API for real-time text translation
- **Languages**: Support for 12+ languages including regional Indian languages
- **Voice**: Web Speech API integration for text-to-speech and speech-to-text

### Location Services
- **Maps**: OpenStreetMap with Leaflet for mapping functionality
- **Geocoding**: Nominatim service for address resolution
- **Tracking**: Real-time GPS location sharing capabilities

## External Dependencies

### Core Infrastructure
- **Database**: PostgreSQL with Neon serverless hosting
- **File Storage**: Planned integration with Supabase or Firebase Storage
- **Development**: Replit environment with custom tooling

### AI & Intelligence
- **Chat AI**: Groq AI for conversational trip planning
- **Voice Processing**: OpenAI Whisper for voice recognition
- **Translation**: LibreTranslate API for multilingual support

### Location & Weather
- **Mapping**: OpenStreetMap and Leaflet for interactive maps
- **Geocoding**: Nominatim for location services
- **Weather**: Open-Meteo API for weather information
- **Routing**: OpenRouteService for navigation

### Communication
- **Email**: SMTP.js for email notifications
- **SMS**: Twilio or Fast2SMS for text messaging
- **Real-time**: Planned WebSocket integration for live features

### UI & Styling
- **Component Library**: Radix UI for accessible components
- **Icons**: Lucide React for consistent iconography
- **Animation**: Framer Motion for smooth interactions
- **Styling**: Tailwind CSS with custom design system

### Development Tools
- **Build Tool**: Vite for fast development and building
- **Type Checking**: TypeScript for compile-time safety
- **Code Quality**: ESLint and Prettier for code standards
- **Testing**: Planned integration with testing frameworks