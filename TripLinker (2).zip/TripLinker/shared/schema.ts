import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  name: text("name"),
  role: text("role").notNull().default("tourist"), // tourist, guide, admin
  language: text("language").default("en"),
  isVerified: boolean("is_verified").default(false),
  verificationData: jsonb("verification_data"), // for guide verification
  createdAt: timestamp("created_at").defaultNow()
});

export const destinations = pgTable("destinations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  country: text("country").notNull(),
  state: text("state").notNull(),
  district: text("district"),
  localArea: text("local_area"),
  description: text("description"),
  images: jsonb("images").$type<string[]>().default([]),
  tags: jsonb("tags").$type<string[]>().default([]),
  latitude: real("latitude"),
  longitude: real("longitude"),
  rating: real("rating").default(0),
  reviewCount: integer("review_count").default(0),
  guidesAvailable: integer("guides_available").default(0)
});

export const guides = pgTable("guides", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  name: text("name").notNull(),
  bio: text("bio"),
  specialization: text("specialization"),
  experience: integer("experience"), // years
  languages: jsonb("languages").$type<string[]>().default([]),
  location: text("location").notNull(),
  rate: integer("rate"), // per day in local currency
  rating: real("rating").default(0),
  reviewCount: integer("review_count").default(0),
  isAvailable: boolean("is_available").default(true),
  avatar: text("avatar"),
  verificationStatus: text("verification_status").default("pending") // pending, verified, rejected
});

export const trips = pgTable("trips", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  destinations: jsonb("destinations").$type<string[]>().default([]),
  itinerary: jsonb("itinerary"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  status: text("status").default("planning"), // planning, confirmed, completed
  createdAt: timestamp("created_at").defaultNow()
});

export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  role: text("role").notNull(), // user, assistant
  timestamp: timestamp("timestamp").defaultNow()
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true
});

export const insertDestinationSchema = createInsertSchema(destinations).omit({
  id: true
});

export const insertGuideSchema = createInsertSchema(guides).omit({
  id: true
});

export const insertTripSchema = createInsertSchema(trips).omit({
  id: true,
  createdAt: true
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  timestamp: true
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Destination = typeof destinations.$inferSelect;
export type InsertDestination = z.infer<typeof insertDestinationSchema>;
export type Guide = typeof guides.$inferSelect;
export type InsertGuide = z.infer<typeof insertGuideSchema>;
export type Trip = typeof trips.$inferSelect;
export type InsertTrip = z.infer<typeof insertTripSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
