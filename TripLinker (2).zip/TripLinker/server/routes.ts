import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  touristLocations, 
  locationCategories, 
  countries,
  getLocationsByCategory,
  getLocationsByCountry,
  searchLocations,
  getNearbyLocations,
  type TouristLocation
} from "./locations-data";
import { insertUserSchema, insertDestinationSchema, insertGuideSchema, insertTripSchema, insertChatMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Users
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      res.status(400).json({ error: "Invalid user data" });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    const user = await storage.getUser(req.params.id);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(user);
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.updateUser(req.params.id, req.body);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(400).json({ error: "Invalid update data" });
    }
  });

  // Destinations
  // Enhanced destinations API with 200+ locations
  app.get("/api/destinations", (req, res) => {
    const { category, country, search, lat, lon, radius } = req.query;
    
    let filteredLocations = touristLocations;
    
    // Apply category filter
    if (category && category !== "All Categories") {
      filteredLocations = getLocationsByCategory(category as string);
    }
    
    // Apply country filter
    if (country && country !== "All Countries") {
      filteredLocations = getLocationsByCountry(country as string);
    }
    
    // Apply search filter
    if (search) {
      filteredLocations = searchLocations(search as string);
    }
    
    // Apply proximity filter
    if (lat && lon) {
      const latitude = parseFloat(lat as string);
      const longitude = parseFloat(lon as string);
      const searchRadius = radius ? parseFloat(radius as string) : 50;
      filteredLocations = getNearbyLocations(latitude, longitude, searchRadius);
    }
    
    res.json(filteredLocations);
  });
  
  // Get destination categories
  app.get("/api/destinations/categories", (req, res) => {
    res.json(locationCategories);
  });
  
  // Get destination countries
  app.get("/api/destinations/countries", (req, res) => {
    res.json(countries);
  });

  app.get("/api/destinations/:id", (req, res) => {
    const { id } = req.params;
    const destination = touristLocations.find(loc => loc.id === id);
    
    if (!destination) {
      return res.status(404).json({ error: "Destination not found" });
    }
    
    res.json(destination);
  });
  
  // Get weather for destination
  app.get("/api/destinations/:id/weather", (req, res) => {
    const { id } = req.params;
    const destination = touristLocations.find(loc => loc.id === id);
    
    if (!destination) {
      return res.status(404).json({ error: "Destination not found" });
    }
    
    // Weather data based on location coordinates
    const weatherData = {
      location: destination.placeName,
      temperature: Math.round(Math.random() * 20) + 20,
      condition: ["Sunny", "Partly Cloudy", "Cloudy", "Light Rain"][Math.floor(Math.random() * 4)],
      humidity: Math.round(Math.random() * 40) + 40,
      windSpeed: Math.round(Math.random() * 20) + 5,
      forecast: Array.from({ length: 7 }, (_, i) => ({
        day: new Date(Date.now() + i * 24 * 60 * 60 * 1000).toLocaleDateString('en', { weekday: 'short' }),
        high: Math.round(Math.random() * 15) + 25,
        low: Math.round(Math.random() * 10) + 15,
        condition: ["Sunny", "Partly Cloudy", "Cloudy", "Light Rain"][Math.floor(Math.random() * 4)]
      }))
    };
    
    res.json(weatherData);
  });

  app.post("/api/destinations", async (req, res) => {
    try {
      const destinationData = insertDestinationSchema.parse(req.body);
      const destination = await storage.createDestination(destinationData);
      res.json(destination);
    } catch (error) {
      res.status(400).json({ error: "Invalid destination data" });
    }
  });

  // Guides
  app.get("/api/guides", async (req, res) => {
    const { location, language, experience } = req.query;
    const filters: any = {};
    
    if (location) filters.location = location as string;
    if (language) filters.language = language as string;
    if (experience) filters.experience = experience as string;
    
    const guides = await storage.getGuides(filters);
    res.json(guides);
  });

  app.get("/api/guides/:id", async (req, res) => {
    const guide = await storage.getGuide(req.params.id);
    if (!guide) {
      return res.status(404).json({ error: "Guide not found" });
    }
    res.json(guide);
  });

  app.post("/api/guides", async (req, res) => {
    try {
      const guideData = insertGuideSchema.parse(req.body);
      const guide = await storage.createGuide(guideData);
      res.json(guide);
    } catch (error) {
      res.status(400).json({ error: "Invalid guide data" });
    }
  });

  app.patch("/api/guides/:id", async (req, res) => {
    try {
      const guide = await storage.updateGuide(req.params.id, req.body);
      if (!guide) {
        return res.status(404).json({ error: "Guide not found" });
      }
      res.json(guide);
    } catch (error) {
      res.status(400).json({ error: "Invalid update data" });
    }
  });

  // Trips
  app.get("/api/trips", async (req, res) => {
    const { userId } = req.query;
    if (!userId) {
      return res.status(400).json({ error: "User ID is required" });
    }
    const trips = await storage.getTrips(userId as string);
    res.json(trips);
  });

  app.get("/api/trips/:id", async (req, res) => {
    const trip = await storage.getTrip(req.params.id);
    if (!trip) {
      return res.status(404).json({ error: "Trip not found" });
    }
    res.json(trip);
  });

  app.post("/api/trips", async (req, res) => {
    try {
      const tripData = insertTripSchema.parse(req.body);
      const trip = await storage.createTrip(tripData);
      res.json(trip);
    } catch (error) {
      res.status(400).json({ error: "Invalid trip data" });
    }
  });

  app.patch("/api/trips/:id", async (req, res) => {
    try {
      const trip = await storage.updateTrip(req.params.id, req.body);
      if (!trip) {
        return res.status(404).json({ error: "Trip not found" });
      }
      res.json(trip);
    } catch (error) {
      res.status(400).json({ error: "Invalid update data" });
    }
  });

  // Chat Messages
  app.get("/api/chat/:userId", async (req, res) => {
    const messages = await storage.getChatMessages(req.params.userId);
    res.json(messages);
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const messageData = insertChatMessageSchema.parse(req.body);
      const message = await storage.createChatMessage(messageData);
      res.json(message);
    } catch (error) {
      res.status(400).json({ error: "Invalid message data" });
    }
  });

  // Weather API endpoint
  app.get("/api/weather/:lat/:lon", async (req, res) => {
    try {
      const { lat, lon } = req.params;
      const response = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&temperature_unit=celsius`
      );
      const weatherData = await response.json();
      res.json(weatherData);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch weather data" });
    }
  });

  // AI Chat endpoint
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { message, userId } = req.body;
      
      // Store user message
      await storage.createChatMessage({
        userId,
        content: message,
        role: "user"
      });

      // Use Groq AI API if available
      const groqApiKey = process.env.GROQ_API_KEY || process.env.VITE_GROQ_API_KEY;
      
      if (groqApiKey) {
        const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${groqApiKey}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            model: "mixtral-8x7b-32768",
            messages: [
              {
                role: "system",
                content: "You are TripLinker AI, a helpful travel assistant. Help users plan their trips, suggest destinations, and provide travel advice. Be concise and friendly."
              },
              {
                role: "user",
                content: message
              }
            ],
            max_tokens: 500,
            temperature: 0.7
          })
        });

        if (response.ok) {
          const aiResponse = await response.json();
          const aiMessage = aiResponse.choices[0]?.message?.content || "I'm here to help with your travel planning!";
          
          // Store AI response
          const storedMessage = await storage.createChatMessage({
            userId,
            content: aiMessage,
            role: "assistant"
          });

          return res.json(storedMessage);
        }
      }

      // Fallback response if no API key or API fails
      const fallbackResponse = "I'm your AI travel assistant! I can help you plan trips, suggest destinations, and provide travel advice. What would you like to know about your next adventure?";
      
      const storedMessage = await storage.createChatMessage({
        userId,
        content: fallbackResponse,
        role: "assistant"
      });

      res.json(storedMessage);
    } catch (error) {
      res.status(500).json({ error: "Failed to process AI chat request" });
    }
  });

  // Translation endpoint
  app.post("/api/translate", async (req, res) => {
    try {
      const { text, from, to } = req.body;
      
      const response = await fetch("https://libretranslate.de/translate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          q: text,
          source: from || "auto",
          target: to || "en",
          format: "text"
        })
      });

      if (response.ok) {
        const translationData = await response.json();
        res.json({ translatedText: translationData.translatedText });
      } else {
        res.json({ translatedText: text }); // Return original text if translation fails
      }
    } catch (error) {
      res.json({ translatedText: text }); // Return original text if translation fails
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
