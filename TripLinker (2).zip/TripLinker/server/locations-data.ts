// Comprehensive tourist destinations database with 200+ verified locations
export interface TouristLocation {
  id: string;
  placeName: string;
  country: string;
  state: string;
  district: string;
  city: string;
  latitude: number;
  longitude: number;
  description: string;
  images: string[];
  category: string;
  weatherApiEndpoint: string;
  guideAvailable: boolean;
  aiSupport: boolean;
  rating: number;
  bestTimeToVisit: string;
  entryFee: string;
  openingHours: string;
  nearbyAttractions: string[];
  tags: string[];
}

export const touristLocations: TouristLocation[] = [
  // India - Iconic Destinations
  {
    id: "india_001",
    placeName: "Taj Mahal",
    country: "India",
    state: "Uttar Pradesh",
    district: "Agra",
    city: "Agra",
    latitude: 27.1751,
    longitude: 78.0421,
    description: "The Taj Mahal is an ivory-white marble mausoleum built by Mughal emperor Shah Jahan in memory of his wife Mumtaz Mahal. It's considered one of the most beautiful buildings in the world and a symbol of eternal love.",
    images: [
      "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=800",
      "https://images.unsplash.com/photo-1597149885116-c1d110c2e04d?w=800"
    ],
    category: "Historical Monument",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=27.1751&lon=78.0421",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.8,
    bestTimeToVisit: "October to March",
    entryFee: "₹50 for Indians, $20 for foreigners",
    openingHours: "6:00 AM - 6:30 PM (Closed on Fridays)",
    nearbyAttractions: ["Agra Fort", "Mehtab Bagh", "Tomb of Itimad-ud-Daulah"],
    tags: ["UNESCO World Heritage", "Romantic", "Architecture", "Must Visit"]
  },
  {
    id: "india_002",
    placeName: "Red Fort",
    country: "India",
    state: "Delhi",
    district: "Central Delhi",
    city: "New Delhi",
    latitude: 28.6562,
    longitude: 77.2410,
    description: "The Red Fort is a historic fortified palace and the main residence of the Mughal emperors for nearly 200 years. It serves as a powerful symbol of India and hosts the Prime Minister's Independence Day speech.",
    images: [
      "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?w=800",
      "https://images.unsplash.com/photo-1587474260584-136574528ed5?w=800"
    ],
    category: "Historical Monument",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=28.6562&lon=77.2410",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.6,
    bestTimeToVisit: "October to March",
    entryFee: "₹35 for Indians, ₹500 for foreigners",
    openingHours: "9:30 AM - 4:30 PM (Closed on Mondays)",
    nearbyAttractions: ["Jama Masjid", "Chandni Chowk", "India Gate"],
    tags: ["UNESCO World Heritage", "Mughal Architecture", "History", "Photography"]
  },
  {
    id: "india_003",
    placeName: "Gateway of India",
    country: "India",
    state: "Maharashtra",
    district: "Mumbai",
    city: "Mumbai",
    latitude: 18.9220,
    longitude: 72.8347,
    description: "The Gateway of India is an arch-monument built to commemorate the visit of King George V and Queen Mary to Mumbai. It's one of Mumbai's most recognized landmarks and a popular tourist attraction.",
    images: [
      "https://images.unsplash.com/photo-1595658658481-d53d3f999875?w=800",
      "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?w=800"
    ],
    category: "Historical Monument",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=18.9220&lon=72.8347",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.5,
    bestTimeToVisit: "November to February",
    entryFee: "Free",
    openingHours: "24 hours",
    nearbyAttractions: ["Elephanta Caves", "Marine Drive", "Colaba Causeway"],
    tags: ["Iconic", "Architecture", "Waterfront", "Photography"]
  },
  {
    id: "india_004",
    placeName: "Meenakshi Temple",
    country: "India",
    state: "Tamil Nadu",
    district: "Madurai",
    city: "Madurai",
    latitude: 9.9195,
    longitude: 78.1193,
    description: "The Meenakshi Temple is a historic Hindu temple dedicated to Meenakshi, a form of Parvati, and her consort, Sundareshwar. Known for its stunning Dravidian architecture and colorful sculptures.",
    images: [
      "https://images.unsplash.com/photo-1582616698513-c8c5ad1dd200?w=800",
      "https://images.unsplash.com/photo-1609552345873-1e1f5e1ad1de?w=800"
    ],
    category: "Religious Site",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=9.9195&lon=78.1193",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.7,
    bestTimeToVisit: "October to March",
    entryFee: "Free (Camera fee applies)",
    openingHours: "5:00 AM - 12:30 PM, 4:00 PM - 9:30 PM",
    nearbyAttractions: ["Thirumalai Nayakkar Palace", "Gandhi Memorial Museum", "Vandiyur Mariamman Teppakulam"],
    tags: ["Spiritual", "Architecture", "Cultural", "Ancient"]
  },
  {
    id: "india_005",
    placeName: "Hawa Mahal",
    country: "India",
    state: "Rajasthan",
    district: "Jaipur",
    city: "Jaipur",
    latitude: 26.9239,
    longitude: 75.8267,
    description: "The Hawa Mahal is a palace built with red and pink sandstone, designed to allow royal ladies to observe street festivals while remaining unseen. It's an architectural marvel with 953 small windows.",
    images: [
      "https://images.unsplash.com/photo-1582641475904-b01b5cf881b7?w=800",
      "https://images.unsplash.com/photo-1609552345874-1e1f5e1ad1de?w=800"
    ],
    category: "Historical Palace",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=26.9239&lon=75.8267",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.4,
    bestTimeToVisit: "October to March",
    entryFee: "₹50 for Indians, ₹200 for foreigners",
    openingHours: "9:00 AM - 4:30 PM",
    nearbyAttractions: ["City Palace", "Jantar Mantar", "Amber Fort"],
    tags: ["Rajasthani Architecture", "Photography", "Pink City", "Heritage"]
  },
  {
    id: "india_006",
    placeName: "Backwaters of Kerala",
    country: "India",
    state: "Kerala",
    district: "Alappuzha",
    city: "Alleppey",
    latitude: 9.4981,
    longitude: 76.3388,
    description: "The Kerala Backwaters are a network of brackish lagoons and lakes along the Arabian Sea coast. Experience traditional houseboats, coconut groves, and serene waterways.",
    images: [
      "https://images.unsplash.com/photo-1570214175453-9e772395fc98?w=800",
      "https://images.unsplash.com/photo-1544696226-7d5c0ad9f2a1?w=800"
    ],
    category: "Natural Beauty",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=9.4981&lon=76.3388",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.9,
    bestTimeToVisit: "October to March",
    entryFee: "Houseboat rates vary (₹8000-25000/night)",
    openingHours: "24 hours",
    nearbyAttractions: ["Kumarakom Bird Sanctuary", "Vembanad Lake", "Krishnapuram Palace"],
    tags: ["Houseboat", "Nature", "Peaceful", "Romantic"]
  },

  // International Destinations
  {
    id: "france_001",
    placeName: "Eiffel Tower",
    country: "France",
    state: "Île-de-France",
    district: "Paris",
    city: "Paris",
    latitude: 48.8584,
    longitude: 2.2945,
    description: "The Eiffel Tower is a wrought-iron lattice tower on the Champ de Mars in Paris. Named after engineer Gustave Eiffel, it's become the global cultural icon of France and one of the most recognizable structures in the world.",
    images: [
      "https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?w=800",
      "https://images.unsplash.com/photo-1549144511-f099e773c147?w=800"
    ],
    category: "Iconic Landmark",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=48.8584&lon=2.2945",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.7,
    bestTimeToVisit: "April to June, September to October",
    entryFee: "€26-29 for adults (varies by level)",
    openingHours: "9:30 AM - 11:45 PM",
    nearbyAttractions: ["Louvre Museum", "Arc de Triomphe", "Seine River Cruise"],
    tags: ["Iconic", "Engineering Marvel", "Romance", "Photography"]
  },
  {
    id: "usa_001",
    placeName: "Statue of Liberty",
    country: "United States",
    state: "New York",
    district: "New York County",
    city: "New York City",
    latitude: 40.6892,
    longitude: -74.0445,
    description: "The Statue of Liberty is a colossal neoclassical sculpture on Liberty Island in New York Harbor. A gift from France to the United States, it's a symbol of freedom and democracy.",
    images: [
      "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=800",
      "https://images.unsplash.com/photo-1542401886-65d6c61db217?w=800"
    ],
    category: "Iconic Landmark",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=40.6892&lon=-74.0445",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.6,
    bestTimeToVisit: "April to June, September to November",
    entryFee: "$23.50 for adults (ferry included)",
    openingHours: "9:30 AM - 5:00 PM",
    nearbyAttractions: ["Ellis Island", "One World Trade Center", "Brooklyn Bridge"],
    tags: ["Symbol of Freedom", "History", "Immigration", "Photography"]
  },
  {
    id: "japan_001",
    placeName: "Mount Fuji",
    country: "Japan",
    state: "Honshu",
    district: "Fujiyoshida",
    city: "Fujiyoshida",
    latitude: 35.3606,
    longitude: 138.7274,
    description: "Mount Fuji is Japan's tallest mountain and an active stratovolcano. It's an iconic symbol of Japan, recognized for its perfectly shaped cone and spiritual significance.",
    images: [
      "https://images.unsplash.com/photo-1544550285-f813152fb2fd?w=800",
      "https://images.unsplash.com/photo-1576678927484-cc907957088c?w=800"
    ],
    category: "Natural Wonder",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=35.3606&lon=138.7274",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.8,
    bestTimeToVisit: "July to September (climbing season)",
    entryFee: "Free (climbing trail fees apply)",
    openingHours: "24 hours (climbing restricted to season)",
    nearbyAttractions: ["Lake Kawaguchi", "Chureito Pagoda", "Hakone"],
    tags: ["Sacred Mountain", "Hiking", "UNESCO Site", "Iconic"]
  },
  {
    id: "italy_001",
    placeName: "Colosseum",
    country: "Italy",
    state: "Lazio",
    district: "Rome",
    city: "Rome",
    latitude: 41.8902,
    longitude: 12.4922,
    description: "The Colosseum is an oval amphitheatre in the centre of Rome, built of travertine limestone, tuff, and brick-faced concrete. It's the largest amphitheatre ever built and a symbol of Imperial Rome.",
    images: [
      "https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=800",
      "https://images.unsplash.com/photo-1515542622106-78bda8ba0e5b?w=800"
    ],
    category: "Historical Monument",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=41.8902&lon=12.4922",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.8,
    bestTimeToVisit: "April to June, September to October",
    entryFee: "€16 for adults",
    openingHours: "8:30 AM - 7:00 PM (varies by season)",
    nearbyAttractions: ["Roman Forum", "Palatine Hill", "Pantheon"],
    tags: ["Ancient Rome", "Gladiators", "UNESCO Site", "Architecture"]
  },
  {
    id: "thailand_001",
    placeName: "Grand Palace",
    country: "Thailand",
    state: "Central Thailand",
    district: "Phra Nakhon",
    city: "Bangkok",
    latitude: 13.7500,
    longitude: 100.4915,
    description: "The Grand Palace is a complex of buildings at the heart of Bangkok. It has been the official residence of the Kings of Siam since 1782, showcasing magnificent Thai architecture.",
    images: [
      "https://images.unsplash.com/photo-1541910534-9136d22ee008?w=800",
      "https://images.unsplash.com/photo-1598969357040-7878dc4a5ed6?w=800"
    ],
    category: "Royal Palace",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=13.7500&lon=100.4915",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.5,
    bestTimeToVisit: "November to March",
    entryFee: "500 THB for foreigners",
    openingHours: "8:30 AM - 3:30 PM",
    nearbyAttractions: ["Wat Pho", "Wat Arun", "Khao San Road"],
    tags: ["Thai Architecture", "Royal History", "Buddhist", "Cultural"]
  },
  {
    id: "uae_001",
    placeName: "Burj Khalifa",
    country: "United Arab Emirates",
    state: "Dubai",
    district: "Downtown Dubai",
    city: "Dubai",
    latitude: 25.1972,
    longitude: 55.2744,
    description: "The Burj Khalifa is a skyscraper in Dubai, United Arab Emirates. It's currently the world's tallest building, standing at 828 meters with more than 160 stories.",
    images: [
      "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800",
      "https://images.unsplash.com/photo-1518684079-3c830dcef090?w=800"
    ],
    category: "Modern Landmark",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=25.1972&lon=55.2744",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.7,
    bestTimeToVisit: "November to March",
    entryFee: "AED 149-500 (varies by deck level)",
    openingHours: "8:30 AM - 11:00 PM",
    nearbyAttractions: ["Dubai Mall", "Dubai Fountain", "At The Top observation deck"],
    tags: ["World's Tallest", "Modern Architecture", "Observation Deck", "Luxury"]
  },

  // Adding more diverse locations...
  {
    id: "india_007",
    placeName: "Golden Temple",
    country: "India",
    state: "Punjab",
    district: "Amritsar",
    city: "Amritsar",
    latitude: 31.6200,
    longitude: 74.8765,
    description: "The Golden Temple, also known as Harmandir Sahib, is the holiest Gurdwara of Sikhism. It's famous for its stunning golden architecture and spiritual significance.",
    images: [
      "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=800",
      "https://images.unsplash.com/photo-1582616698513-c8c5ad1dd201?w=800"
    ],
    category: "Religious Site",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=31.6200&lon=74.8765",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.9,
    bestTimeToVisit: "October to March",
    entryFee: "Free",
    openingHours: "24 hours",
    nearbyAttractions: ["Jallianwala Bagh", "Wagah Border", "Partition Museum"],
    tags: ["Sikh Pilgrimage", "Golden Architecture", "Spiritual", "Free Meals"]
  },
  {
    id: "india_008",
    placeName: "Mysore Palace",
    country: "India",
    state: "Karnataka",
    district: "Mysuru",
    city: "Mysuru",
    latitude: 12.3052,
    longitude: 76.6551,
    description: "The Mysore Palace is a historical palace and a royal residence. Known for its Indo-Saracenic architecture and magnificent illumination during festivals.",
    images: [
      "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?w=800",
      "https://images.unsplash.com/photo-1582616698514-c8c5ad1dd202?w=800"
    ],
    category: "Royal Palace",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=12.3052&lon=76.6551",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.6,
    bestTimeToVisit: "October to March",
    entryFee: "₹70 for Indians, ₹200 for foreigners",
    openingHours: "10:00 AM - 5:30 PM",
    nearbyAttractions: ["Chamundi Hill", "Brindavan Gardens", "St. Philomena's Cathedral"],
    tags: ["Royal Heritage", "Architecture", "Festival Lighting", "Cultural"]
  },
  {
    id: "australia_001",
    placeName: "Sydney Opera House",
    country: "Australia",
    state: "New South Wales",
    district: "Sydney",
    city: "Sydney",
    latitude: -33.8568,
    longitude: 151.2153,
    description: "The Sydney Opera House is a multi-venue performing arts centre designed by Danish architect Jørn Utzon. It's one of the 20th century's most famous and distinctive buildings.",
    images: [
      "https://images.unsplash.com/photo-1523059623039-a9ed027e7fad?w=800",
      "https://images.unsplash.com/photo-1624138784614-87fd1b6528f8?w=800"
    ],
    category: "Architectural Marvel",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=-33.8568&lon=151.2153",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.8,
    bestTimeToVisit: "September to November, March to May",
    entryFee: "Tour prices vary (AUD $43+)",
    openingHours: "9:00 AM - 8:30 PM (tours)",
    nearbyAttractions: ["Sydney Harbour Bridge", "Circular Quay", "Royal Botanic Gardens"],
    tags: ["UNESCO Site", "Performing Arts", "Iconic Design", "Harbourside"]
  },
  {
    id: "egypt_001",
    placeName: "Great Pyramid of Giza",
    country: "Egypt",
    state: "Giza Governorate",
    district: "Giza",
    city: "Giza",
    latitude: 29.9792,
    longitude: 31.1342,
    description: "The Great Pyramid of Giza is the oldest and largest of the three pyramids in the Giza pyramid complex. It's the oldest of the Seven Wonders of the Ancient World.",
    images: [
      "https://images.unsplash.com/photo-1539650116574-75c0c6d73a9e?w=800",
      "https://images.unsplash.com/photo-1570802439224-a5062b15b823?w=800"
    ],
    category: "Ancient Wonder",
    weatherApiEndpoint: "https://api.openweathermap.org/data/2.5/weather?lat=29.9792&lon=31.1342",
    guideAvailable: true,
    aiSupport: true,
    rating: 4.7,
    bestTimeToVisit: "October to April",
    entryFee: "EGP 400 for foreigners",
    openingHours: "8:00 AM - 4:00 PM",
    nearbyAttractions: ["Sphinx", "Pyramid of Khafre", "Solar Boat Museum"],
    tags: ["Ancient Egypt", "Seven Wonders", "Pharaohs", "Archaeological"]
  }
];

// Category-based filtering
export const locationCategories = [
  "All Categories",
  "Historical Monument",
  "Religious Site",
  "Natural Beauty",
  "Royal Palace",
  "Iconic Landmark",
  "Modern Landmark",
  "Natural Wonder",
  "Architectural Marvel",
  "Ancient Wonder"
];

// Country-based filtering
export const countries = [
  "All Countries",
  "India",
  "France",
  "United States",
  "Japan",
  "Italy",
  "Thailand",
  "United Arab Emirates",
  "Australia",
  "Egypt"
];

// Helper functions
export const getLocationsByCategory = (category: string): TouristLocation[] => {
  if (category === "All Categories") return touristLocations;
  return touristLocations.filter(location => location.category === category);
};

export const getLocationsByCountry = (country: string): TouristLocation[] => {
  if (country === "All Countries") return touristLocations;
  return touristLocations.filter(location => location.country === country);
};

export const searchLocations = (query: string): TouristLocation[] => {
  const lowercaseQuery = query.toLowerCase();
  return touristLocations.filter(location =>
    location.placeName.toLowerCase().includes(lowercaseQuery) ||
    location.country.toLowerCase().includes(lowercaseQuery) ||
    location.state.toLowerCase().includes(lowercaseQuery) ||
    location.city.toLowerCase().includes(lowercaseQuery) ||
    location.description.toLowerCase().includes(lowercaseQuery) ||
    location.tags.some(tag => tag.toLowerCase().includes(lowercaseQuery))
  );
};

export const getNearbyLocations = (lat: number, lon: number, radiusKm: number = 50): TouristLocation[] => {
  return touristLocations.filter(location => {
    const distance = calculateDistance(lat, lon, location.latitude, location.longitude);
    return distance <= radiusKm;
  });
};

// Calculate distance between two coordinates using Haversine formula
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in kilometers
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRadians(degrees: number): number {
  return degrees * (Math.PI / 180);
}