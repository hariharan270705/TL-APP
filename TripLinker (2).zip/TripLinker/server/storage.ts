import { type User, type InsertUser, type Destination, type InsertDestination, type Guide, type InsertGuide, type Trip, type InsertTrip, type ChatMessage, type InsertChatMessage } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<User>): Promise<User | undefined>;

  // Destinations
  getDestinations(filters?: { search?: string; tags?: string[] }): Promise<Destination[]>;
  getDestination(id: string): Promise<Destination | undefined>;
  createDestination(destination: InsertDestination): Promise<Destination>;

  // Guides
  getGuides(filters?: { location?: string; language?: string; experience?: string }): Promise<Guide[]>;
  getGuide(id: string): Promise<Guide | undefined>;
  getGuidesByUserId(userId: string): Promise<Guide[]>;
  createGuide(guide: InsertGuide): Promise<Guide>;
  updateGuide(id: string, guide: Partial<Guide>): Promise<Guide | undefined>;

  // Trips
  getTrips(userId: string): Promise<Trip[]>;
  getTrip(id: string): Promise<Trip | undefined>;
  createTrip(trip: InsertTrip): Promise<Trip>;
  updateTrip(id: string, trip: Partial<Trip>): Promise<Trip | undefined>;

  // Chat Messages
  getChatMessages(userId: string): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private destinations: Map<string, Destination>;
  private guides: Map<string, Guide>;
  private trips: Map<string, Trip>;
  private chatMessages: Map<string, ChatMessage>;

  constructor() {
    this.users = new Map();
    this.destinations = new Map();
    this.guides = new Map();
    this.trips = new Map();
    this.chatMessages = new Map();
    this.initializeData();
  }

  private initializeData() {
    // Initialize with sample destinations
    const destinations: Destination[] = [
      {
        id: "dest-1",
        name: "Leh Ladakh",
        country: "India",
        state: "Jammu & Kashmir",
        district: "Leh",
        localArea: "Leh Town",
        description: "Breathtaking high-altitude desert with Buddhist monasteries and stunning landscapes",
        images: ["https://images.unsplash.com/photo-1506905925346-21bda4d32df4"],
        tags: ["Mountain", "Adventure", "Buddhist", "High Altitude"],
        latitude: 34.1526,
        longitude: 77.5771,
        rating: 4.8,
        reviewCount: 247,
        guidesAvailable: 12
      },
      {
        id: "dest-2",
        name: "Andaman Islands",
        country: "India",
        state: "Andaman & Nicobar",
        district: "South Andaman",
        localArea: "Port Blair",
        description: "Tropical paradise with pristine beaches and crystal clear waters",
        images: ["https://images.unsplash.com/photo-1559827260-dc66d52bef19"],
        tags: ["Beach", "Island", "Diving", "Tropical"],
        latitude: 11.7401,
        longitude: 92.6586,
        rating: 4.9,
        reviewCount: 189,
        guidesAvailable: 8
      },
      {
        id: "dest-3",
        name: "Rajasthan Heritage",
        country: "India",
        state: "Rajasthan",
        district: "Jaipur",
        localArea: "Pink City",
        description: "Royal palaces, forts, and vibrant culture of the desert state",
        images: ["https://images.unsplash.com/photo-1524492412937-b28074a5d7da"],
        tags: ["Heritage", "Palace", "Culture", "Desert"],
        latitude: 26.9124,
        longitude: 75.7873,
        rating: 4.7,
        reviewCount: 356,
        guidesAvailable: 25
      }
    ];

    destinations.forEach(dest => this.destinations.set(dest.id, dest));

    // Initialize with sample guides
    const guides: Guide[] = [
      {
        id: "guide-1",
        userId: "user-guide-1",
        name: "Rajesh Kumar",
        bio: "Experienced mountain guide with deep knowledge of Ladakhi culture and high-altitude trekking",
        specialization: "Mountain trekking expert",
        experience: 8,
        languages: ["English", "Hindi", "Ladakhi"],
        location: "Leh, Ladakh",
        rate: 2500,
        rating: 4.9,
        reviewCount: 47,
        isAvailable: true,
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e",
        verificationStatus: "verified"
      },
      {
        id: "guide-2",
        userId: "user-guide-2",
        name: "Priya Sharma",
        bio: "Cultural heritage specialist with expertise in Rajasthani history and traditions",
        specialization: "Cultural heritage guide",
        experience: 5,
        languages: ["English", "Hindi", "Rajasthani"],
        location: "Jaipur, Rajasthan",
        rate: 1800,
        rating: 4.8,
        reviewCount: 62,
        isAvailable: true,
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786",
        verificationStatus: "verified"
      },
      {
        id: "guide-3",
        userId: "user-guide-3",
        name: "Arjun Nair",
        bio: "Water sports enthusiast and island hopping expert with marine biology background",
        specialization: "Water sports & island hopping",
        experience: 6,
        languages: ["English", "Hindi", "Malayalam"],
        location: "Port Blair, Andaman",
        rate: 3000,
        rating: 4.7,
        reviewCount: 38,
        isAvailable: true,
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d",
        verificationStatus: "verified"
      }
    ];

    guides.forEach(guide => this.guides.set(guide.id, guide));
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date(),
      isVerified: false,
      verificationData: null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, userUpdate: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userUpdate };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Destination methods
  async getDestinations(filters?: { search?: string; tags?: string[] }): Promise<Destination[]> {
    let destinations = Array.from(this.destinations.values());
    
    if (filters?.search) {
      const search = filters.search.toLowerCase();
      destinations = destinations.filter(dest => 
        dest.name.toLowerCase().includes(search) ||
        dest.state.toLowerCase().includes(search) ||
        dest.country.toLowerCase().includes(search)
      );
    }

    if (filters?.tags && filters.tags.length > 0) {
      destinations = destinations.filter(dest =>
        filters.tags!.some(tag => dest.tags.includes(tag))
      );
    }

    return destinations;
  }

  async getDestination(id: string): Promise<Destination | undefined> {
    return this.destinations.get(id);
  }

  async createDestination(insertDestination: InsertDestination): Promise<Destination> {
    const id = randomUUID();
    const destination: Destination = { 
      ...insertDestination, 
      id,
      rating: 0,
      reviewCount: 0,
      guidesAvailable: 0
    };
    this.destinations.set(id, destination);
    return destination;
  }

  // Guide methods
  async getGuides(filters?: { location?: string; language?: string; experience?: string }): Promise<Guide[]> {
    let guides = Array.from(this.guides.values());

    if (filters?.location) {
      guides = guides.filter(guide => 
        guide.location.toLowerCase().includes(filters.location!.toLowerCase())
      );
    }

    if (filters?.language) {
      guides = guides.filter(guide =>
        guide.languages.some(lang => lang.toLowerCase().includes(filters.language!.toLowerCase()))
      );
    }

    if (filters?.experience) {
      const expRange = filters.experience;
      guides = guides.filter(guide => {
        if (expRange === "1-3") return guide.experience! >= 1 && guide.experience! <= 3;
        if (expRange === "3-5") return guide.experience! >= 3 && guide.experience! <= 5;
        if (expRange === "5+") return guide.experience! >= 5;
        return true;
      });
    }

    return guides.filter(guide => guide.verificationStatus === "verified");
  }

  async getGuide(id: string): Promise<Guide | undefined> {
    return this.guides.get(id);
  }

  async getGuidesByUserId(userId: string): Promise<Guide[]> {
    return Array.from(this.guides.values()).filter(guide => guide.userId === userId);
  }

  async createGuide(insertGuide: InsertGuide): Promise<Guide> {
    const id = randomUUID();
    const guide: Guide = { 
      ...insertGuide, 
      id,
      rating: 0,
      reviewCount: 0,
      isAvailable: true,
      verificationStatus: "pending"
    };
    this.guides.set(id, guide);
    return guide;
  }

  async updateGuide(id: string, guideUpdate: Partial<Guide>): Promise<Guide | undefined> {
    const guide = this.guides.get(id);
    if (!guide) return undefined;
    
    const updatedGuide = { ...guide, ...guideUpdate };
    this.guides.set(id, updatedGuide);
    return updatedGuide;
  }

  // Trip methods
  async getTrips(userId: string): Promise<Trip[]> {
    return Array.from(this.trips.values()).filter(trip => trip.userId === userId);
  }

  async getTrip(id: string): Promise<Trip | undefined> {
    return this.trips.get(id);
  }

  async createTrip(insertTrip: InsertTrip): Promise<Trip> {
    const id = randomUUID();
    const trip: Trip = { 
      ...insertTrip, 
      id,
      createdAt: new Date(),
      status: "planning"
    };
    this.trips.set(id, trip);
    return trip;
  }

  async updateTrip(id: string, tripUpdate: Partial<Trip>): Promise<Trip | undefined> {
    const trip = this.trips.get(id);
    if (!trip) return undefined;
    
    const updatedTrip = { ...trip, ...tripUpdate };
    this.trips.set(id, updatedTrip);
    return updatedTrip;
  }

  // Chat methods
  async getChatMessages(userId: string): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter(msg => msg.userId === userId)
      .sort((a, b) => a.timestamp!.getTime() - b.timestamp!.getTime());
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const message: ChatMessage = { 
      ...insertMessage, 
      id,
      timestamp: new Date()
    };
    this.chatMessages.set(id, message);
    return message;
  }
}

export const storage = new MemStorage();
